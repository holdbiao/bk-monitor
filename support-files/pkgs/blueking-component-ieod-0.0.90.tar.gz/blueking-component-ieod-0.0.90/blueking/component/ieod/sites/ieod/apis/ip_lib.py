# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIpLib(object):
    """Collections of IP_LIB APIS"""

    def __init__(self, client):
        self.client = client

        self.get_ip_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ip_lib/get_ip_status/',
            description=u'查询状态'
        )
        self.search_ip = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ip_lib/search_ip/',
            description=u'查询ip信息'
        )
