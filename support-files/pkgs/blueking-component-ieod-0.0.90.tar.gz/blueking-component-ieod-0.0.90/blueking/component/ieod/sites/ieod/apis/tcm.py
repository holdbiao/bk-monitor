# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTCM(object):
    """Collections of TCM APIS"""

    def __init__(self, client):
        self.client = client

        self.create_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcm/create_task/',
            description=u'创建新任务'
        )
        self.get_app_by_user = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcm/get_app_by_user/',
            description=u'查询用户有权限的业务列表'
        )
        self.get_app_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcm/get_app_info/',
            description=u'查询业务信息'
        )
        self.get_task_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcm/get_task_result/',
            description=u'查询任务执行结果'
        )
        self.get_task_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcm/get_task_status/',
            description=u'查询任务执行状态'
        )
        self.get_template_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcm/get_template_info/',
            description=u'查询新手模板参数内容'
        )
        self.get_templates = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcm/get_templates/',
            description=u'查询新手模板列表'
        )
        self.run_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcm/run_task/',
            description=u'执行任务'
        )
        self.start_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcm/start_task/',
            description=u'创建并启动任务'
        )
        self.task_ctrl = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcm/task_ctrl/',
            description=u'任务流程控制'
        )
