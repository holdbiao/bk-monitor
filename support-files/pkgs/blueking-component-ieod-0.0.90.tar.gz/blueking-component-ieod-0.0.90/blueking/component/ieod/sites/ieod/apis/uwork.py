# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsUWORK(object):
    """Collections of UWORK APIS"""

    def __init__(self, client):
        self.client = client

        self.get_alarm_ticket = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/uwork/get_alarm_ticket/',
            description=u'查询uwork告警单'
        )
        self.get_noc_notice_status = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/uwork/get_noc_notice_status/',
            description=u'查询uwork事件单'
        )
        self.get_server_event = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/uwork/get_server_event/',
            description=u'查询uwork事件单'
        )
        self.get_server_restart_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/uwork/get_server_restart_status/',
            description=u'查询重启任务状态'
        )
        self.query_reinstall_os_by_dept = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/uwork/query_reinstall_os_by_dept/',
            description=u'按部门查询重装服务器信息'
        )
        self.query_reinstall_os_by_server_ip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/uwork/query_reinstall_os_by_server_ip/',
            description=u'根据服务器IP查询重装的状态'
        )

        self.noc_notice = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/uwork/noc_notice/',
            description=u'自动语音通知流程起单'
        )
