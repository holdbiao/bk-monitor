# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIJOBS2(object):
    """Collections of IJOBS2 APIS"""

    def __init__(self, client):
        self.client = client

        self.get_agent_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_agent_status/',
            description=u'通过输入ip集合检测ip集合的agent状态'
        )
        self.get_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_application/',
            description=u'查询业务列表'
        )
        self.get_batch_task_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_batch_task_status/',
            description=u'批量查询作业状态'
        )
        self.get_crontab_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_crontab_list/',
            description=u'获取轮询定时任务列表'
        )
        self.get_ip_category = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_ip_category/',
            description=u'获取执行IJOBIP结果分类'
        )
        self.get_operate_type = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_operate_type/',
            description=u'获取实例步骤允许操作的按钮类型'
        )
        self.get_step_ip_log = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_step_ip_log/',
            description=u'查询指定步骤指定IP的日志'
        )
        self.get_task_log = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_task_log/',
            description=u'获取作业执行日志'
        )
        self.get_task_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_task_status/',
            description=u'根据作业实例ID, 查看作业执行状态'
        )
        self.get_taski_details = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_taski_details/',
            description=u'根据作业执行态, 获取该执行态的全程设置信息'
        )
        self.get_taskis = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_taskis/',
            description=u'获取模版下作业执行态信息'
        )
        self.get_taskts = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_taskts/',
            description=u'按条件查询作业模版列表'
        )
        self.get_user_account = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_user_account/',
            description=u'获取业务下的常用账户'
        )
        self.get_taski_mtime = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/get_taski_mtime/',
            description=u'获取执行态最后更新时间'
        )
        self.poll_check_task_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/ijobs2/poll_check_task_status/',
            description=u'轮询IJOBS执行实例的状态'
        )

        self.agent_management = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ijobs2/agent_management/',
            description=u'管理Agent'
        )
        self.batch_exec_taski = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ijobs2/batch_exec_taski/',
            description=u'通过指定执行态ID，批量执行作业'
        )
        self.batch_exec_taski = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ijobs2/batch_exec_taski/',
            description=u'通过指定执行态ID，批量执行作业'
        )
        self.exec_taski = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ijobs2/exec_taski/',
            description=u'执行执行态'
        )
        self.exec_task_step = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ijobs2/exec_task_step/',
            description=u'操作实例'
        )
