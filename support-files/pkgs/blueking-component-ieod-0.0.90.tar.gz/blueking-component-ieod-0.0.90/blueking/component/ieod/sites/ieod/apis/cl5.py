# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsCL5(object):
    """Collections of CL5 APIS"""

    def __init__(self, client):
        self.client = client

        self.add_callee_ip_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cl5/add_callee_ip_port/',
            description=u'被调扩容'
        )
        self.del_callee_ip_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cl5/del_callee_ip_port/',
            description=u'被调缩容'
        )
        self.update_callee_weight = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cl5/update_callee_weight/',
            description=u'修改被调权重'
        )
