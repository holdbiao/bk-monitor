# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsESB(object):
    """Collections of ESB APIS"""

    def __init__(self, client):
        self.client = client

        self.get_api_public_key = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/esb/get_api_public_key/',
            description=u'获取公钥'
        )
        self.get_components = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/esb/get_components/',
            description=u'获取指定系统的组件列表'
        )
        self.get_systems = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/esb/get_systems/',
            description=u'获取系统列表'
        )
