# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIEDVIP(object):
    """Collections of IEDVIP APIS"""

    def __init__(self, client):
        self.client = client

        self.get_all_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/iedvip/get_all_application/',
            description=u'获取所有业务信息'
        )
        self.get_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/iedvip/get_application/',
            description=u'获取业务信息'
        )
        self.get_ispeed_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/iedvip/get_ispeed_application/',
            description=u'获取ispeed业务列表'
        )
