# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsNODEMAN(object):
    """Collections of NODEMAN APIS"""

    def __init__(self, client):
        self.client = client

        self.ap_list = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/ap/',
            description=u'接入点列表'
        )
        self.cloud_list = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/cloud/',
            description=u'查询云区域'
        )
        self.remove_host = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/host/remove_host/',
            description=u'移除主机'
        )
        self.list_hosts = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/host/search/',
            description=u'查询主机列表'
        )
        self.job_details = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/job/details/',
            description=u'查询任务详情'
        )
        self.job_install = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/job/install/',
            description=u'主机安装'
        )
        self.get_job_log = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/job/log/',
            description=u'查询日志'
        )
        self.job_operate = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/job/operate/',
            description=u'主机操作'
        )
        self.operate_plugin = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/plugin/operate/',
            description=u'插件操作任务'
        )
        self.search_host_plugin = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/api/plugin/search/',
            description=u'查询主机插件'
        )
        self.plugin_create_config_template = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/create_config_template/',
            description=u'创建配置模板'
        )
        self.plugin_create_export_task = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/create_export_task/',
            description=u'触发插件打包导出'
        )
        self.plugin_create_register_task = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/create_register_task/',
            description=u'创建注册任务'
        )
        self.plugin_delete = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/delete/',
            description=u'删除插件'
        )
        self.plugin_info = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/info/',
            description=u'查询插件信息'
        )
        self.plugin_query_debug = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/query_debug/',
            description=u'查询调试结果'
        )
        self.plugin_query_export_task = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/query_export_task/',
            description=u'获取一个导出任务结果'
        )
        self.plugin_query_register_task = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/query_register_task/',
            description=u'查询插件注册任务'
        )
        self.plugin_release = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/release/',
            description=u'发布插件'
        )
        self.plugin_release_config_template = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/release_config_template/',
            description=u'发布配置模板'
        )
        self.plugin_render_config_template = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/render_config_template/',
            description=u'渲染配置模板'
        )
        self.plugin_start_debug = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/start_debug/',
            description=u'开始调试'
        )
        self.plugin_stop_debug = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/plugin/stop_debug/',
            description=u'停止调试'
        )
        self.subscription_task_result_detail = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/collect_task_result_detail/',
            description=u'采集任务执行详细结果'
        )
        self.subscription_create = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/create/',
            description=u'创建订阅任务'
        )
        self.subscription_delete = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/delete/',
            description=u'删除订阅'
        )
        self.fetch_commands = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/fetch_commands/',
            description=u'获取命令'
        )
        self.subscription_info = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/info/',
            description=u'订阅详情'
        )
        self.subscription_instance_status = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/instance_status/',
            description=u'查询订阅运行状态'
        )
        self.subscription_retry = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/retry/',
            description=u'重试失败的任务'
        )
        self.subscription_revoke = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/revoke/',
            description=u'终止正在执行的任务'
        )
        self.subscription_run = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/run/',
            description=u'执行订阅'
        )
        self.subscription_switch = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/switch/',
            description=u'订阅启停'
        )
        self.subscription_task_result = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/task_result/',
            description=u'任务执行结果'
        )
        self.subscription_task_result_detail = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/task_result_detail/',
            description=u'任务执行详细结果'
        )
        self.subscription_update = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/backend/api/subscription/update/',
            description=u'更新订阅'
        )
        self.create_cloud = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/create_cloud/',
            description=u'新增云区域'
        )
        self.create_task = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/create_task/',
            description=u'新增任务'
        )
        self.get_cloud = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/get_clouds/',
            description=u'查询云区域'
        )
        self.get_clouds_by_biz = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/get_clouds_by_biz/',
            description=u'查询业务下的云区域列表'
        )
        self.get_log = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/get_log/',
            description=u'获取日志'
        )
        self.get_task_info = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/get_task_info/',
            description=u'根据id获取任务执行信息'
        )
        self.register_package = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/package/',
            description=u'注册插件包信息'
        )
        self.plugin_create_config_template = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_create_config_template/',
            description=u'创建插件配置模板'
        )
        self.plugin_create_export_task = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_create_export_task/',
            description=u'创建插件包导出任务'
        )
        self.plugin_create_register_task = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_create_register_task/',
            description=u'创建插件注册任务'
        )
        self.plugin_delete = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_delete/',
            description=u'删除插件'
        )
        self.plugin_info = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_info/',
            description=u'查询插件信息'
        )
        self.plugin_query_debug = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_query_debug/',
            description=u'查询插件调试状态'
        )
        self.plugin_query_export_task = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_query_export_task/',
            description=u'查询插件包导出任务状态'
        )
        self.plugin_query_register_task = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_query_register_task/',
            description=u'查询插件注册任务状态'
        )
        self.plugin_release = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_release/',
            description=u'发布插件包'
        )
        self.plugin_release_config_template = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_release_config_template/',
            description=u'发布插件配置模板'
        )
        self.plugin_render_config_template = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_render_config_template/',
            description=u'渲染插件配置模板'
        )
        self.plugin_start_debug = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_start_debug/',
            description=u'启动插件调试'
        )
        self.plugin_stop_debug = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/plugin_stop_debug/',
            description=u'停止插件调试'
        )
        self.register_process = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/process/',
            description=u'注册插件信息'
        )
        self.get_process_by_name = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/process/{process_name}/',
            description=u'根据插件名获取插件信息'
        )
        self.register_process_info = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/process_info/',
            description=u'注册插件安装信息'
        )
        self.get_process_info_by_name = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/process_info/{process_name}/',
            description=u'根据插件名获取插件安装信息'
        )
        self.query_hosts = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/query_hosts/',
            description=u'获取主机信息'
        )
        self.subscription_create = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_create/',
            description=u'创建订阅配置'
        )
        self.subscription_delete = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_delete/',
            description=u'删除订阅配置'
        )
        self.subscription_info = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_info/',
            description=u'查询订阅配置信息'
        )
        self.subscription_instance_status = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_instance_status/',
            description=u'查询订阅实例状态'
        )
        self.subscription_run = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_run/',
            description=u'执行订阅下发任务'
        )
        self.subscription_switch = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_switch/',
            description=u'启停订阅配置'
        )
        self.subscription_task_result = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_task_result/',
            description=u'查询订阅任务状态'
        )
        self.subscription_task_result_detail = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_task_result_detail/',
            description=u'查询订阅任务中实例的详细状态'
        )
        self.subscription_update = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/subscription_update/',
            description=u'更新订阅配置'
        )
        self.get_host = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/{bk_biz_id}/host_status/get_host/',
            description=u'根据插件获取机器信息'
        )
        self.add_task = ComponentAPI(
            client=self.client, method='POST',
            path='/api/c/compapi{bk_api_ver}/nodeman/{bk_biz_id}/tasks/',
            description=u'新增任务'
        )
        self.get_task_info = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/{bk_biz_id}/tasks/{job_id}/',
            description=u'根据id获取任务执行信息'
        )
        self.get_package_by_name = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/nodeman/{process_name}/package/',
            description=u'根据插件名获取插件包信息'
        )
