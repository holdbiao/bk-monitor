# -*- coding: utf-8 -*-
"""Conf for component client"""
import logging

from ...django_conf import (APP_CODE, SECRET_KEY, RUN_MODE, DEFAULT_BK_API_VER,
                            BK_API_USE_BKCLOUDS_FIRST, BK_API_USE_TEST_ENV)
from ...utils import FancyDict

logger = logging.getLogger('component')


__all__ = [
    'APP_CODE',
    'SECRET_KEY',
    'RUN_MODE',
    'DEFAULT_BK_API_VER',
    'BK_API_USE_TEST_ENV',
    'COMPONENT_SYSTEM_HOST',
    'CLIENT_ENABLE_SIGNATURE',
    'AVAILABLE_COLLECTIONS',
]

if RUN_MODE == "PRODUCT":
    COMPONENT_SYSTEM_HOST = 'http://open.oa.com'
else:
    COMPONENT_SYSTEM_HOST = 'http://t.open.oa.com'


CLIENT_ENABLE_SIGNATURE = False

# bkoauth配置项
OAUTH_API_URL = 'http://apigw.o.oa.com'
OAUTH_COOKIES_PARAMS = {'rtx': 'bk_uid', 'bk_ticket': 'bk_ticket', 'oa_ticket': 'ticket'}
try:
    from bkoauth.client import OAuthClient
    oauth_client = OAuthClient(OAUTH_API_URL, OAUTH_COOKIES_PARAMS)
except Exception:
    logger.exception(u'esb sdk 引用 bkoauth 出现异常，access_token 相关功能将不可用，请检查 bkoauth 配置是否正确')
    oauth_client = FancyDict(is_enabled=False)

# Available components

from .apis.alarmweixin import CollectionsALARMWEIXIN  # noqa
from .apis.ams import CollectionsAMS  # noqa
from .apis.cc import CollectionsCC  # noqa
from .apis.chg import CollectionsCHG  # noqa
from .apis.cmdb import CollectionsCMDB  # noqa
from .apis.gcs import CollectionsGCS  # noqa
from .apis.idcspeed import CollectionsIDCSPEED  # noqa
from .apis.idipauth import CollectionsIDIPAUTH  # noqa
from .apis.idip import CollectionsIDIP  # noqa
from .apis.iedvip import CollectionsIEDVIP  # noqa
from .apis.ijobs2 import CollectionsIJOBS2  # noqa
from .apis.imonitor import CollectionsIMONITOR  # noqa
from .apis.inc import CollectionsINC  # noqa
from .apis.itest import CollectionsITEST  # noqa
from .apis.job import CollectionsJOB  # noqa
from .apis.mmwsd import CollectionsMMWSD  # noqa
from .apis.mtcls import CollectionsMTCLS  # noqa
from .apis.mtcls2 import CollectionsMTCLS2  # noqa
from .apis.myoa import CollectionsMYOA  # noqa
from .apis.obs import CollectionsOBS  # noqa
from .apis.odm import CollectionsODM  # noqa
from .apis.rel2 import CollectionsREL2  # noqa
from .apis.sniper import CollectionsSNIPER  # noqa
from .apis.so import CollectionsSO  # noqa
from .apis.tcls import CollectionsTCLS  # noqa
from .apis.tcm import CollectionsTCM  # noqa
from .apis.tgw import CollectionsTGW  # noqa
from .apis.stgw import CollectionsSTGW  # noqa
from .apis.ticket import CollectionsTICKET  # noqa
from .apis.tnm2 import CollectionsTNM2  # noqa
from .apis.tof import CollectionsTOF  # noqa
from .apis.tof3 import CollectionsTOF3  # noqa
from .apis.uwork import CollectionsUWORK  # noqa
from .apis.webplat import CollectionsWEBPLAT  # noqa
from .apis.weixin import CollectionsWEIXIN  # noqa
from .apis.zsd import CollectionsZSD  # noqa
from .apis.gse import CollectionsGSE  # noqa
from .apis.goq import CollectionsGOQ  # noqa
from .apis.tjj import CollectionsTJJ  # noqa
from .apis.tapd import CollectionsTAPD  # noqa
from .apis.smcs import CollectionsSMCS  # noqa
from .apis.cc2 import CollectionsCC2  # noqa
from .apis.gcloud import CollectionsGCLOUD  # noqa
from .apis.gslb import CollectionsGSLB  # noqa
from .apis.cl5 import CollectionsCL5  # noqa
from .apis.qyweixin import CollectionsQYWEIXIN  # noqa
from .apis.lbs import CollectionsLBS  # noqa
from .apis.ip_lib import CollectionsIpLib  # noqa
from .apis.bk_cmdb import CollectionsBkCmdb  # noqa
from .apis.bk_job import CollectionsBkJob  # noqa
from .apis.bk_user import CollectionsBkUser  # noqa
from .apis.nodeman import CollectionsNODEMAN  # noqa
from .apis.bk_gse import CollectionsBkGse  # noqa
from .apis.itsm import CollectionsITSM  # noqa
from .apis.sops import CollectionsSOPS  # noqa
from .apis.esb import CollectionsESB  # noqa
from .apis.cmsi import CollectionsCMSI  # noqa


AVAILABLE_COLLECTIONS = {
    'alarmweixin': CollectionsALARMWEIXIN,
    'qyweixin': CollectionsQYWEIXIN,
    'ams': CollectionsAMS,
    'cc': CollectionsCC,
    'chg': CollectionsCHG,
    'cmdb': CollectionsCMDB,
    'gcs': CollectionsGCS,
    'idcspeed': CollectionsIDCSPEED,
    'idip': CollectionsIDIP,
    'idipauth': CollectionsIDIPAUTH,
    'iedvip': CollectionsIEDVIP,
    'ijobs2': CollectionsIJOBS2,
    'imonitor': CollectionsIMONITOR,
    'inc': CollectionsINC,
    'itest': CollectionsITEST,
    'job': CollectionsJOB,
    'mmwsd': CollectionsMMWSD,
    'mtcls': CollectionsMTCLS,
    'mtcls2': CollectionsMTCLS2,
    'myoa': CollectionsMYOA,
    'obs': CollectionsOBS,
    'odm': CollectionsODM,
    'rel2': CollectionsREL2,
    'sniper': CollectionsSNIPER,
    'so': CollectionsSO,
    'tcls': CollectionsTCLS,
    'tcm': CollectionsTCM,
    'tgw': CollectionsTGW,
    'stgw': CollectionsSTGW,
    'ticket': CollectionsTICKET,
    'tnm2': CollectionsTNM2,
    'tof': CollectionsTOF,
    'tof3': CollectionsTOF3,
    'uwork': CollectionsUWORK,
    'webplat': CollectionsWEBPLAT,
    'weixin': CollectionsWEIXIN,
    'zsd': CollectionsZSD,
    'gse': CollectionsGSE,
    'goq': CollectionsGOQ,
    'tjj': CollectionsTJJ,
    'tapd': CollectionsTAPD,
    'smcs': CollectionsSMCS,
    'cc2': CollectionsCC2,
    'gcloud': CollectionsGCLOUD,
    'gslb': CollectionsGSLB,
    'cl5': CollectionsCL5,
    'lbs': CollectionsLBS,
    'ip_lib': CollectionsIpLib,
    'bk_cmdb': CollectionsBkCmdb,
    'bk_job': CollectionsBkJob,
    'bk_user': CollectionsBkUser,
    'nodeman': CollectionsNODEMAN,
    'bk_gse': CollectionsBkGse,
    'sops': CollectionsSOPS,
    'itsm': CollectionsITSM,
    'esb': CollectionsESB,
    'cmsi': CollectionsCMSI,
}


# if set, use bkclouds apis first for some systems
if BK_API_USE_BKCLOUDS_FIRST:
    AVAILABLE_COLLECTIONS.update({
        'cc': CollectionsBkCmdb,
        'job': CollectionsBkJob,
        'usermanage': CollectionsBkUser,
        'gse': CollectionsBkGse,
    })
