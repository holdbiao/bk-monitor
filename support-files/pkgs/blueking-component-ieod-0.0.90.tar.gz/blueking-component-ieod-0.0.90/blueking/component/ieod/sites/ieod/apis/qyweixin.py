# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsQYWEIXIN(object):
    """Collections of QYWEIXIN APIS"""

    def __init__(self, client):
        self.client = client

        self.create_appchat = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/qyweixin/create_appchat/',
            description=u'创建群聊会话'
        )
        self.get_appchat = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/qyweixin/get_appchat/',
            description=u'获取群聊会话'
        )
        self.send_appchat = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/qyweixin/send_appchat/',
            description=u'应用推送消息'
        )
        self.update_appchat = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/qyweixin/update_appchat/',
            description=u'修改群聊会话'
        )
