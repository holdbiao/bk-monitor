# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsGSLB(object):
    """Collections of GSLB APIS"""

    def __init__(self, client):
        self.client = client

        self.get_domain_record = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gslb/get_domain_record/',
            description=u'查询域名记录'
        )
        self.get_idc_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gslb/get_idc_list/',
            description=u'获取所有的IDC列表'
        )
        self.get_isp_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gslb/get_isp_list/',
            description=u'获取运营商列表'
        )
        self.get_provience_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gslb/get_provience_list/',
            description=u'获取省份列表'
        )
        self.get_region_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gslb/get_region_list/',
            description=u'获取地区列表'
        )
