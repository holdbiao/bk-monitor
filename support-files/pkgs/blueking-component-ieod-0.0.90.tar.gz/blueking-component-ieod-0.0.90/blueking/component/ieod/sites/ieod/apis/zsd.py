# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsZSD(object):
    """Collections of ZSD APIS"""

    def __init__(self, client):
        self.client = client

        self.get_attack_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/zsd/get_attack_info/',
            description=u'获取服务器遭受攻击记录'
        )
