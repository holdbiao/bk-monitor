# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsMYOA(object):
    """Collections of MYOA APIS"""

    def __init__(self, client):
        self.client = client

        self.push_data = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/myoa/push_data/',
            description=u'myoa审批接口'
        )
        self.complete = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/myoa/complete/',
            description=u'结单接口'
        )
        self.workitem_create = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/myoa/workitem_create/',
            description=u'创建审批单据（V3）'
        )
        self.workitem_close = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/myoa/workitem_close/',
            description=u'关闭审批单据（V3）'
        )
