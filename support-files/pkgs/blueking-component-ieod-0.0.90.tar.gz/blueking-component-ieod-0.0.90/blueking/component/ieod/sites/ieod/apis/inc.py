# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsINC(object):
    """Collections of INC APIS"""

    def __init__(self, client):
        self.client = client

        self.create_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/inc/create_task/',
            description=u'建单请求'
        )
        self.end_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/inc/end_task/',
            description=u'提交结单请求'
        )
        self.get_alarms = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/inc/get_alarms/',
            description=u'告警查询'
        )
        self.get_all_fault_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/inc/get_all_fault_info/',
            description=u'故障单查询'
        )
        self.get_onduty_infos = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/inc/get_onduty_infos/',
            description=u'查询值班信息'
        )
