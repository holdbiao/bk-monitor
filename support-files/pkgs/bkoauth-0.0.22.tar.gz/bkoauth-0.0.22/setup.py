# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="bkoauth",
    version="0.0.22",
    author="blueking maintainers",
    author_email="blueking mail",
    url="http://apigw.o.qcloud.com",
    zip_safe=False,
    packages=find_packages(),
    description="blueking oauth",
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: Web Environment',
        'Framework :: Django',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
    ],
    install_requires=[
        'requests',
        'django',
    ],
)
