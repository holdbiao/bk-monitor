# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsCC(object):
    """Collections of CC APIS"""

    def __init__(self, client):
        self.client = client

        self.get_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_application/',
            description=u'获取业务列表'
        )
        self.get_app_list_by_name = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_app_list_by_name/',
            description=u'根据RTX名称查询相关业务'
        )
        self.get_app_module_by_app_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_app_module_by_app_id/',
            description=u'查询业务模块信息'
        )
        self.get_application_staff = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_application_staff/',
            description=u'获取业务相关的员工信息'
        )
        self.get_app_by_user_role = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_app_by_user_role/',
            description=u'根据用户角色查询用户业务'
        )
        self.get_external_resources = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_external_resources/',
            description=u'根据资源类型查询资源表'
        )
        self.get_host_by_app_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_host_by_app_id/',
            description=u'查询该业务下所有主机的详细信息'
        )
        self.get_host_by_app_module_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_host_by_app_module_id/',
            description=u'查询该业务模块下所有主机的信息'
        )
        self.get_host_by_topo_module_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_host_by_topo_module_id/',
            description=u'查询拓扑模块下所有主机的信息'
        )
        self.get_host_by_topo_set_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_host_by_topo_set_id/',
            description=u'查询拓扑Set下所有主机的信息'
        )
        self.get_idc_devices_by_app_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_idc_devices_by_app_id/',
            description=u'查询IDC下业务机型的机器数目'
        )
        self.get_idc_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_idc_list/',
            description=u'查询所有IDC的信息'
        )
        self.get_idc_unit_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_idc_unit_list/',
            description=u'查询所有IDCUnit（机房管理单元）的信息'
        )
        self.get_modify_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_modify_result/',
            description=u'查询CC更新操作结果'
        )
        self.get_parameter_data = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_parameter_data/',
            description=u'根据编码类型查询编码信息'
        )
        self.get_query_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/get_query_info/',
            description=u'CC通用查询'
        )
        self.get_template_tree = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_template_tree/',
            description=u'查询产品模型树'
        )
        self.get_topo_module_by_app_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_topo_module_by_app_id/',
            description=u'查询业务下所有拓扑模块的模块ID和模块名称'
        )
        self.get_topo_module_by_topo_set_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_topo_module_by_topo_set_id/',
            description=u'查询该拓扑Set下面所有拓扑Module的信息'
        )
        self.get_topo_set_by_app_id = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/get_topo_set_by_app_id/',
            description=u'查询该业务下所有拓扑Set的ID和名称'
        )
        self.get_topo_tree = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_topo_tree/',
            description=u'查询分布拓扑树'
        )
        self.get_iplist_by_bill = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_iplist_by_bill/',
            description=u'查询锁单据下IP列表'
        )
        self.get_lock_bill = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_lock_bill/',
            description=u'查询锁单据列表'
        )
        self.get_lock_iplist_by_appid = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_lock_iplist_by_appid/',
            description=u'查询业务下锁定主机列表'
        )
        self.get_update_proc_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc/get_update_proc_status/',
            description=u'获取刷新实例请求状态'
        )

        self.host_module = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/host_module/',
            description=u'修改主机所属模块'
        )
        self.set_instantiate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/set_instantiate/',
            description=u'Set实例化'
        )
        self.set_delete = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/set_delete/',
            description=u'删除Set'
        )
        self.toponode_update = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/toponode_update/',
            description=u'拓扑节点属性更新'
        )
        self.host_property = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/host_property/',
            description=u'主机自定义属性修改'
        )
        self.host_standard_property = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/host_standard_property/',
            description=u'主机标准属性修改'
        )
        self.host_replace = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/host_replace/',
            description=u'主机替换'
        )
        self.update_vip_vport = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/update_vip_vport/',
            description=u'更新VIP+VPort'
        )
        self.update_instance_id = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/update_instance_id/',
            description=u'刷新进程实例'
        )
        self.set_config_vars = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/set_config_vars/',
            description=u'设置业务环境变量'
        )
        self.set_cst_property = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/set_cst_property/',
            description=u'设置Set自定义属性'
        )
        self.add_host_lock = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/add_host_lock/',
            description=u'增加主机锁'
        )
        self.delete_host_lock = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/delete_host_lock/',
            description=u'删除主机锁'
        )
        self.update_bip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/update_bip/',
            description=u'更新BIP信息'
        )
        self.update_bip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cc/update_bip/',
            description=u'更新BIP信息'
        )
