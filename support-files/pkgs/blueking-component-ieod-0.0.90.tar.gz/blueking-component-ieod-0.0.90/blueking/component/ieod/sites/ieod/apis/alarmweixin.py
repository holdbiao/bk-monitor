# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsALARMWEIXIN(object):
    """Collections of ALARMWEIXIN APIS"""

    def __init__(self, client):
        self.client = client

        self.send_appmsg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/alarmweixin/send_appmsg/',
            description=u'发送图文/跳转小程序信息'
        )
        self.send_appmsg2chatroom = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/alarmweixin/send_appmsg2chatroom/',
            description=u'发送图文至微信群'
        )
        self.send_img = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/alarmweixin/send_img/',
            description=u'发送图片信息'
        )
        self.send_img2chatroom = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/alarmweixin/send_img2chatroom/',
            description=u'发送图片信息至微信群'
        )
        self.send_msg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/alarmweixin/send_msg/',
            description=u'发送文字/曲线图/数据表信息'
        )
        self.send_msg2chatroom = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/alarmweixin/send_msg2chatroom/',
            description=u'发信息至微信群'
        )
