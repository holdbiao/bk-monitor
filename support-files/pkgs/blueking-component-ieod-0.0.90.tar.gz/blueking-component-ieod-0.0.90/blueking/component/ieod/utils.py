# -*- coding: utf-8 -*-
import os
import re
import json
import base64
import hmac
import hashlib

import six


def str_bool(value):
    if isinstance(value, six.string_types):
        value = value.strip()
        if value.lower() in ("0", "false"):
            return False
    return bool(value)


def get_current_environ():
    """获取当前组件SDK所工作的环境，如果环境变量中有设置，直接使用环境变量值
    否则通过sites目录下查找。
    """
    if os.environ.get('BK_SDK_ENVIRON'):
        return os.environ['BK_SDK_ENVIRON']

    current_dir = os.path.dirname(os.path.abspath(__file__))
    sites_dir = os.path.join(current_dir, 'sites')
    sites = [d for d in os.listdir(sites_dir)
             if os.path.isdir(os.path.join(sites_dir, d)) and not re.search(r'^[\._]', d)]
    if not sites:
        raise Exception('Unable to initialize package, no available site found.')
    return sites[0]


def get_signature(method, path, app_secret, params=None, data=None):
    """generate signature
    """
    kwargs = {}
    if params:
        kwargs.update(params)
    if data:
        data = json.dumps(data) if isinstance(data, dict) else data
        kwargs['data'] = data
    kwargs = '&'.join([
        '%s=%s' % (k, v)
        for k, v in sorted(kwargs.items(), key=lambda x: x[0])
    ])
    orignal = '%s%s?%s' % (method, path, kwargs)
    app_secret = app_secret.encode('utf-8') if isinstance(app_secret, six.text_type) else app_secret
    orignal = orignal.encode('utf-8') if isinstance(orignal, six.text_type) else orignal
    signature = base64.b64encode(hmac.new(app_secret, orignal, hashlib.sha1).digest())
    return signature if isinstance(signature, six.text_type) else signature.decode('utf-8')


class FancyDict(dict):

    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError as k:
            raise AttributeError(k)

    def __setattr__(self, key, value):
        self[key] = value

    def __delattr__(self, key):
        try:
            del self[key]
        except KeyError as k:
            raise AttributeError(k)


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        return x_forwarded_for
    return request.META.get('REMOTE_ADDR', '')
