# Release notes

## 1.0.10
- 新功能
    - 【开发框架】项目初始化，支持内部版 ieod 版本

## 1.0.11
- bugfix
	- 【开发框架】修复开发样例的 default 中 celery 配置问题

## 1.0.12
- bugfix
	- 【开发框架】修复开发样例的功能开关模块代码异常

## 1.0.13
- 新功能
	- 【开发框架】settings 配置新增 CELERY_CONCURRENCY 变量，支持用户通过设置环境变量或者修改配置控制 celery worker 并发数
	- 【开发框架】异常处理逻辑增加通知 sentry 功能，并兼容不开启 sentry 功能的 APP
	
## 1.0.14
- 新功能
    - 【开发框架】初始化框架 conf/default.py 新增 INIT_SUPERUSER 配置，默认为 APP 创建人（内部版RTX，混合云版QQ号），第一次部署时会被初始化为管理员（去掉 init_data APP）
- 优化项
    - 【开发样例】bk-admin 命令通过 json 文件增量覆盖默认配置，去掉全量替换逻辑
- bugfix
    - 【开发框架】去掉数据库配置中的 CONN_MAX_AGE，避免多线程中报错数据库失联
    - 【开发样例】修复开发样例 celery.tasks 路径的错误

## 1.0.15
- 新功能
    - 【开发框架】支持 PaaS3.0 混合云 clouds 版本
- 优化项
    - 【开发样例】代码架构优化

## 1.0.16
- 新功能
    - 【开发框架】支持 python3.6 版本，兼容 python2.7 版本
    - 【开发框架】支持 PaaS3.0 外部版 tencent 版本

## 1.0.17
- 新功能
    - 【开发框架】企业版 PaaS2.0 兼容
    - 【开发框架】新增 blueapps.utils.logger 模块，可以直接引用 logger 和 logger_celery
    - 【开发框架】默认开启 PaaS 平台的增强服务
    - 【开发样例】新增微信端支持，新增微信端开发样例，使用 bk-admin startweixin 生成
- 优化项
    - 【开发框架】blueapps 包打印的日志类型由 component 改为 blueapps，即打印在用户日志中
    - 【开发样例】代码规范化，样例 APP 都改为 "app_" 开头
    - 【开发样例】去掉性能测试样例
    - 【开发样例】水印样例删除字体文件，使用默认字体
- bugfix
    - 【开发框架】修复 bk-admin 关键字参数 secret_key、run_ver 类型错误
    - 【开发框架】修复独立域名下 STATIC_URL 拼接错误问题
    
## 1.0.18
- 优化项
    - 修复登录模块部分安全问题
- bugfix
    - 开发样例依赖包 pillow 版本升级，修复旧版本非 Linux 系统下不兼容 python3 的问题

## 1.0.19
- 优化项
    - readme 文档更新
- bugfix
    - 修复开发框架客户端包渲染初始化管理员错误问题

## 1.0.20
- 优化项
    - mako渲染支持XSS过滤
    - 各个版本登录框优化显示方式，兼容权限申请页面

## 1.0.21
- 新功能
    - 增加微信小程序开发样例
    - 增加智能网关身份验证逻辑
    
## 1.1.0
- 新功能
    - 【开发样例】增加二步验证功能样例
    - 【开发框架】Account model增加短信验证功能
- bugfix
    - 【开发框架】修正Account登录跳转逻辑支持独立非oa域名登录
    
## 1.1.1
- 优化项
    - 支持独立域名及平台域名同时使用

## 1.1.2
- 优化项
    - 增加XSS处理中间件
    
## 1.1.3
- 优化项
    - 优化外部版本（tencent, clouds）登录跳转为https
        
## 1.1.4
- 优化
    - 将celery / component日志句柄的日志级别改为由用户自定义控制
    - 正式环境日志级别默认改为ERROR
- 修复
    - 修复bk_token判断管理员身份失效的问题
    
## 1.2.0
- 新功能
    - 增加用户身份信息接口，配合bkui使用
    - 增加blueapps.middleware.bkui.middlewares.BkuiPageMiddleware中间件，配合bkui使用
- 优化
    - 日志配置内容，增加django.server句柄配置
    - 调整异常模块
    
## 1.2.1
- 优化
    - 优化对外版本首页显示内容
    
## 1.2.2
- 优化
    - 默认在context_process增加BK_STATIC_URL配置
    
## 1.2.3
- 优化
    - 升级依赖的django版本为1.11.23
    
## 1.2.4
- 优化
    - 增加屏蔽版本差异的用户信息获取方法

## 1.2.5
- 新功能
   - 调整日志路径，支持开发者中心多模块功能
   
## 1.2.6
- 优化
   - 更新requests依赖版本
   
   
## 2.2.7
- 修复
   - 修复celery日志打印未有落地文件问题
- 其他
   - 更新版本号，与对外版本对齐
   
## 2.3.0
- 新功能
    - 支持PaaS独立域名功能支持
    
## 2.4.0
- 新功能
    - 优化样例页面样式，统一内外版本样例
    
## 2.5.0
- 新功能
    - 支持jwt验证方式

## 3.0.0
- 新功能
    - 支持django2.2版本
    
## 3.0.1
- 修复
    - 修复jwt下，ESB使用白名单方式导致登录事变
    - 修复py3下，RIO登录存在问题
- 功能
    - 支持对外版本下支持登录弹框的能力

## 3.1.0
- 优化
    - 去掉对外版本下SaaS用户管理和平台同步逻辑

## 3.2.0
- 优化
    - 增加样例国际化
    
## 3.2.1
- 修复
    - 修复bk-admin startexample 命令生成开发样例适配不同平台调用不同的接口获取业务列表
    - blueapps/conf/project_template/config/__init__.py 增加 get_env_or_raise(key)函数
    - 国际化单词矫正(django1.11.x -> django2.x)

## 3.2.2
- 新功能
    - 增加获取app_host的函数 `get_app_host_by_request(request)`
    - 增加 `REMOTE_ANALYSIS_URL` saas 访问统计js url
    - 增加 `REMOTE_API_URL` paas 提供的前端 api.js url
    - 增加 `APIGW_APP_CODE_KEY` 从 apigw jwt 中获取 app_code 键
    - 增加 `APIGW_USER_USERNAME_KEY` 从 apigw jwt 中获取用户名的键
    
## 3.2.3
- 优化
    - 在文件中增加开源版权头信息
    - 修改open版本的csrf_token的`CSRF_COOKIE_NAME`值 为 `csrftoken`

## 3.2.4
- 优化
    - session过期时间使用默认值两周
    - 登录信息缓存改为使用cache缓存
    - admin管理页面增加用户名和是否管理员的过滤条件

## 3.2.5
- 优化
    - 对代码进行 pep8 优化
    
## 3.2.6
- 修复
    - 修复登录失效时无正常触发登录问题
- 优化
    - 优化session_id根据app_code动态发生变化
    
## 3.2.7
- 优化
    - 依赖的markupSafe依赖版本配置更改为1.1.1
    - 增加bk_ticket支持rio的登录方式

