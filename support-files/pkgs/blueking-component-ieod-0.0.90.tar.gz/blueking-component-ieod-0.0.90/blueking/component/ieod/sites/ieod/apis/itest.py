# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsITEST(object):
    """Collections of ITEST APIS"""

    def __init__(self, client):
        self.client = client

        self.create_bill = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/itest/create_bill/',
            description=u'创建转测单'
        )

        self.get_base_line = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_base_line/',
            description=u'获取对应项目版本的基线信息'
        )

        self.get_bill_detail = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_bill_detail/',
            description=u'获取转测单详情'
        )

        self.get_templates_ids = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_templates_ids/',
            description=u'查询项目所有转测模板ID'
        )

        self.get_test_bill = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_test_bill/',
            description=u'获取转测单'
        )

        self.get_test_master = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_test_master/',
            description=u'获取项目测试经理'
        )

        self.get_version_and_base_line = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_version_and_base_line/',
            description=u'获取对应项目版本和基线信息'
        )

        self.get_version_number = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_version_number/',
            description=u'获取对应项目版本信息'
        )

        self.get_template_by_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/itest/get_template_by_id/',
            description=u'查询项目指定转测模板'
        )
