# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsCHG(object):
    """Collections of CHG APIS"""

    def __init__(self, client):
        self.client = client

        self.blue_post_del = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/chg/blue_post_del/',
            description=u'变更删单'
        )
        self.blue_post_renovate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/chg/blue_post_renovate/',
            description=u'变更结单'
        )
        self.blue_post_start = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/chg/blue_post_start/',
            description=u'变更提单'
        )
        self.get_change_type = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/chg/get_change_type/',
            description=u'查询变更类型'
        )
