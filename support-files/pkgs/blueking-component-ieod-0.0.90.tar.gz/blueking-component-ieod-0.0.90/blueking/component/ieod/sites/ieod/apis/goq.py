# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsGOQ(object):
    """Collections of GOQ APIS"""

    def __init__(self, client):
        self.client = client

        self.operate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/goq/operate/',
            description=u'大区信息同步'
        )
