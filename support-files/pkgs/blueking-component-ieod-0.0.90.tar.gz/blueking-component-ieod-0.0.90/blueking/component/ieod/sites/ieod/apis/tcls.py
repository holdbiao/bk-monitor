# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTCLS(object):
    """Collections of TCLS APIS"""

    def __init__(self, client):
        self.client = client

        self.add_grayinfos = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/add_grayinfos/',
            description=u'添加版本的灰度信息'
        )
        self.add_rollbackinfos = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/add_rollbackinfos/',
            description=u'添加版本的回滚信息'
        )
        self.add_tree_nodes = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/add_tree_nodes/',
            description=u'添加节点'
        )
        self.add_versions = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/add_versions/',
            description=u'生效更新'
        )
        self.append_qq_whites = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/append_qq_whites/',
            description=u'添加QQ白名单'
        )
        self.batch_append_qq_whites = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/batch_append_qq_whites/',
            description=u'批量添加QQ白名单'
        )
        self.batch_modify_nodes = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/batch_modify_nodes/',
            description=u'批量修改大区某些属性为相同的值'
        )
        self.batch_modify_qq_whites = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/batch_modify_qq_whites/',
            description=u'批量更改QQ白名单'
        )
        self.cancel_qq_white = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/cancel_qq_white/',
            description=u'取消QQ白名单'
        )
        self.delete_grayinfos = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/delete_grayinfos/',
            description=u'生效更新'
        )
        self.delete_qq_white = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/delete_qq_white/',
            description=u'删除QQ白名单'
        )
        self.delete_rollbackinfos = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/delete_rollbackinfos/',
            description=u'删除版本的回滚信息'
        )
        self.download_tdir_cfg = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/download_tdir_cfg/',
            description=u'下载目录配置'
        )
        self.download_tver_cfg = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/download_tver_cfg/',
            description=u'下载版本配置'
        )
        self.get_business = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_business/',
            description=u'获取业务名称，业务ID'
        )
        self.get_children_nodes = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/get_children_nodes/',
            description=u'获取子节点'
        )
        self.get_env_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_env_list/',
            description=u'获取业务环境列表'
        )
        self.get_global_download_address = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_global_download_address/',
            description=u'获取版本服务器全局下载地址'
        )
        self.get_iptable = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_iptable/',
            description=u'获取IP白名单'
        )
        self.get_lock_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_lock_info/',
            description=u'获取锁信息'
        )
        self.get_qq_white_by = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/get_qq_white_by/',
            description=u'获取QQ白名单'
        )
        self.get_server_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_server_info/',
            description=u'获取业务信息'
        )
        self.get_tdir_node_qq_white = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_tdir_node_qq_white/',
            description=u'获取目录节点QQ白名单'
        )
        self.get_tdir_nodes_by = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/get_tdir_nodes_by/',
            description=u'根据条件获取大区集合'
        )
        self.get_version_infos = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/get_version_infos/',
            description=u'获取版本信息'
        )
        self.get_version_numbers = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tcls/get_version_numbers/',
            description=u'获取版本号列表'
        )
        self.lock_middle_env = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/lock_middle_env/',
            description=u'锁定中转服'
        )
        self.modify_clientcommcfg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/modify_clientcommcfg/',
            description=u'生效更新'
        )
        self.modify_diff_config = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/modify_diff_config/',
            description=u'修改目录树差量生效配置'
        )
        self.modify_nodes = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/modify_nodes/',
            description=u'批量修改大区节点'
        )
        self.modify_qq_whites = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/modify_qq_whites/',
            description=u'更改QQ白名单'
        )
        self.modify_versions = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/modify_versions/',
            description=u'生效更新'
        )
        self.publish = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/publish/',
            description=u'中转服配置发布正式服'
        )
        self.refresh_env_cfg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/refresh_env_cfg/',
            description=u'生效更新'
        )
        self.set_iptable = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/set_iptable/',
            description=u'设置iptable'
        )
        self.sync_env_cfg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/sync_env_cfg/',
            description=u'正式服、中转服、测试服版本目录配置同步'
        )
        self.unlock_middle_env = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/unlock_middle_env/',
            description=u'解锁中转服'
        )
        self.upload_tdir_cfg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/upload_tdir_cfg/',
            description=u'上传目录配置'
        )
        self.upload_tver_cfg = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tcls/upload_tver_cfg/',
            description=u'上传版本配置'
        )
