//app.js
/*
*  蓝鲸内部版小程序登录模块
*/

var bk = require('./auth/auth.js')
var configs = require('./config.js')

App({
	globalData: {
		debug: configs.DEBUG,
		isLogin: false,
		userInfo: {},
		staffInfo: {},
		isIphoneX: false
	},

	...bk,
	onLaunch: function () {
		let that = this;
		this.authorize(function(res) {
			that.isLogin = true

			that.globalData.userInfo = {
				'uid': res.staffID,
				'username': res.engName
			}
		})
	},

	onShow:function(){
		let  that = this;
		wx.getSystemInfo({
			success:  res=>{
				let modelmes = res.model;
				if (modelmes.search('iPhone X') != -1) {
					that.globalData.isIphoneX = true
				}
			}
		})
	}
})
