"""A setuptools based setup module.

See:
https://packaging.python.org/en/latest/distributing.html
https://github.com/pypa/sampleproject
"""

# To use a consistent encoding
from codecs import open
from os import path

# Always prefer setuptools over distutils
from setuptools import find_packages, setup

here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()
version = __import__('blueapps').__version__

setup(
    name='blueapps',

    # Versions should comply with PEP440.  For a discussion on single-sourcing
    # the version across setup.py and the project code, see
    # https://packaging.python.org/en/latest/single_source_version.html
    version=version,

    description='development framework for blueking',
    long_description=long_description,

    # The project's main homepage.
    url='http://gitlab-paas.open.oa.com/app_framework/blueapps',

    # Author details
    author='blueking',
    author_email='blueking@tencent.com',
    include_package_data=True,

    # You can just specify the packages manually here if your project is
    # simple. Or you can use find_packages().
    packages=find_packages(),

    # Alternatively, if you want to distribute just a my_module.py, uncomment
    # this:
    #   py_modules=["my_module"],

    # List run-time dependencies here.  These will be installed by pip when
    # your project is installed. For an analysis of "install_requires" vs pip's
    # requirements files see:
    # https://packaging.python.org/en/latest/requirements.html
    install_requires=[
        'Django==2.2.6',
        'mysqlclient==1.4.4',
        'MarkupSafe==1.1.1',
        'Mako==1.0.6',
        'requests==2.22.0',
        'celery==3.1.25',
        'django-celery==3.2.1',
        'python-json-logger==0.1.7',
        'whitenoise==3.3.0',
        'six==1.11.0'
    ],
    zip_safe=False,
    # To provide executable scripts, use entry points in preference to the
    # "scripts" keyword. Entry points provide cross-platform support and allow
    # pip to create the appropriate form of executable for the target platform.
    entry_points={
        'console_scripts': [
            'bk-admin=blueapps.contrib.bk_commands:bk_admin',
        ],
    },
)
