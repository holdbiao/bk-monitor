# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTGW(object):
    """Collections of TGW APIS"""

    def __init__(self, client):
        self.client = client

        self.add_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/add_rs/',
            description=u'RS上线'
        )
        self.apply = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/apply/',
            description=u'TGW业务上线申请'
        )
        self.block_alarm = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/block_alarm/',
            description=u'TGW屏蔽告警'
        )
        self.del_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/del_rs/',
            description=u'RS下线'
        )
        self.del_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/del_rule/',
            description=u'下线规则'
        )
        self.get_alarm_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tgw/get_alarm_info/',
            description=u'获取告警信息'
        )
        self.get_app_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/get_app_info/',
            description=u'根据规则查询业务配置信息'
        )
        self.get_apply_state = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tgw/get_apply_state/',
            description=u'查询申请单状态'
        )
        self.get_idc_by_app = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tgw/get_idc_by_app/',
            description=u'根据TGW业务名称获取IDC'
        )
        self.get_isp_city = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tgw/get_isp_city/',
            description=u'查询运营商与城市对应关系'
        )
        self.get_job_state = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tgw/get_job_state/',
            description=u'查询任务状态'
        )
        self.get_natisp = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tgw/get_natisp/',
            description=u'根据城市查询NAT运营商'
        )
        self.get_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/get_rs/',
            description=u'查询RS'
        )
        self.get_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/get_rule/',
            description=u'查询Rule'
        )
        self.get_tgw_app_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/get_tgw_app_info/',
            description=u'查询app_id和一二级业务关系'
        )
        self.get_vip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/get_vip/',
            description=u'查询VIP信息'
        )
        self.install_nat = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/install_nat/',
            description=u'安装NAT'
        )
        self.keep_time = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/keep_time/',
            description=u'修改会话保持时间'
        )
        self.refresh_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/refresh_rs/',
            description=u'刷新RS'
        )
        self.rs_weight = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/rs_weight/',
            description=u'修改RS权重'
        )
        self.switch_fault_machine = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/tgw_switch_fault_machine/',
            description=u'RS故障机替换'
        )
        self.unblock_alarm = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/unblock_alarm/',
            description=u'解屏蔽告警'
        )
        self.uninstall_nat = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tgw/uninstall_nat/',
            description=u'下线NAT'
        )
