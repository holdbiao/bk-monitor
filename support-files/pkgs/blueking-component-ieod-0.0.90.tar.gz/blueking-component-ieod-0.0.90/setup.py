# -*- coding: utf-8 -*-
from setuptools import setup, find_packages


setup(
    name='blueking-component-ieod',
    version='0.0.90',
    author='blueking team',
    description='Python SDK for blueking [component]',

    packages=find_packages(),
    namespace_packages=['blueking.component'],
    include_package_data=True,
    install_requires=[
        'requests',
        'six',
        'bkoauth>=0.0.10',
    ]
)
