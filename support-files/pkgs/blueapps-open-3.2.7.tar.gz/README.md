# blueapps(蓝鲸开发框架)

## Installation

To install using `pip`:

```bash
$ pip install blueapps
```

## Usage


### 生成开发框架
```bash
$ bk-admin init <app_code> [directory]
```

### 生成 Django APP
```bash
$ bk-admin startapp <app_name>
```


### 生成开发样例
```bash
$ bk-admin startexample
```

