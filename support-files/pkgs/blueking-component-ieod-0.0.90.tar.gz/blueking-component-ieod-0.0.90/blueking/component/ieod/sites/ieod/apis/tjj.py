# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTJJ(object):
    """Collections of TJJ APIS"""

    def __init__(self, client):
        self.client = client

        self.update_password = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tjj/update_password/',
            description=u'更新密码接口'
        )

        self.get_task_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tjj/get_task_status/',
            description=u'查询任务状态'
        )
