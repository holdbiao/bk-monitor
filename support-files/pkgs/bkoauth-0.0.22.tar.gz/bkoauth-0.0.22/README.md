## Blueking OAuth / Django App

### 简介
蓝鲸APIGateWay使用Oauth2.0协议，调用接口需要先获取access_token才能调用API， bkoauth是access_token获取，自动刷新的一个SDK包

### 安装&使用
1， pip安装SDK包
```
pip install bkoauth
```

2， 把bkoauth添加到INSTALL_APPS
```python
INSTALLED_APPS = (
    ...
    'bkoauth'  # 把bkoauth添加到INSTALL_APPS即可
)
```
3, 同步数据库
```
python migrate
```
### API
bkoauth 提供3个API分别为get_access_token, get_app_access_token, refresh_token

###### 1， 获取用户级别access_token
```python
### 调用函数获取
from bkoauth import get_access_token
access_token = get_access_token(request)
```

###### 2，获取APP级别access_token
```python
from bkoauth import get_app_access_token
access_token = get_app_access_token()
```

###### 3，刷新access_token
```python
from bkoauth import refresh_token
access_token = refresh_token(access_token)  # access_token从API 1,2方法得到
```

###### 4，使用用户ID获取access_token
```python
from bkoauth import get_access_token_by_user
access_token = get_access_token_by_user(user_id)  # user_id是用户的主字符串, 和request.user.username相同
# 正常返回 access_token model对象
# 异常抛出 bkoauth.exceptions.TokenNotExist 异常
```

### 特性
1. 独立安装包，安装升级方便
2. 使用auth.signals.user_logged_in信号机制自动生成access_token,续期access_token


### 开发框架升级
1. 把bkoauth添加到INSTALL_APPS即可
2. 添加配置项
3. 每次用户登录后，会自动生成access_token，如果一天之内过期，则自动续期


### 配置
1， ieod版本
```python
OAUTH_API_URL = 'http://apigw.o.oa.com'
OAUTH_COOKIES_PARAMS = {'rtx': 'bk_uid', 'bk_ticket': 'bk_ticket'}
```

2， tencent版本
```python
OAUTH_API_URL = 'http://apigw.o.oa.com'
OAUTH_COOKIES_PARAMS = {'uin': 'p_uin', 'skey': 'p_skey'}
OAUTH_PARAMS = {'bk_env': 'tencent'}
```

3， clouds版本
```python
OAUTH_API_URL = 'http://apigw.o.oa.com'
OAUTH_COOKIES_PARAMS = {'uin': 'p_uin', 'skey': 'p_skey'}
OAUTH_PARAMS = {'bk_env': 'clouds'}
```

4， qcloud版本
```python
OAUTH_API_URL = 'https://apigw.o.qcloud.com'
OAUTH_COOKIES_PARAMS = {'openid': 'openid', 'openkey': 'openkey'}
```

### apigw装饰器
```python
from bkoauth.decorators import apigw_required
from account.decorators import login_exempt
# 在settings设置API公钥
PUBLIC_KEY = """
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAv/053PzqnGHAtC6XfAh9
wIt1XBKzu0v8EAOAvn1QoDw3tTjhWF13djTglxofOI/TYeKlHtmSNk2o0LroLcsX
dEnO3U4XiFN307FEA72GwUhEKlRyxclkVcYmjDliwpC93AduaFj+ZxK1PATmIZbB
gJTXYSqNYSea3yZH0Kter/kOF1Zic90ZP+6wjFK57OD6Gw602F7El7HAI3QFlnj7
XgrGbnuYs2nED6L/o+lpkUJCSDXaCc4AiIMnPeDZ9dmUfRei8pmMALl+eUd77tCJ
hwmPhbhWsSxEdG0aXQXnc8ekxqolqW9lxOIppyZmsk72WeiJT5ApLm3n3BoKk6kb
hQIDAQAB
-----END PUBLIC KEY-----
"""
@login_exempt
@apigw_required
def api_debug(request):
    request.jwt.app.app_code  # 包含APP信息，详情见http://apigw-joe.o.oa.com/docs/page/authentications
    request.jwt.user.username # 包含用户信息，详情见http://apigw-joe.o.oa.com/docs/page/authentications
```
