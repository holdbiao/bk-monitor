import os
from codecs import open
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README.md'), encoding="utf-8") as readme:
    README = readme.read()

# allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

setup(
    name='django-versionlog',
    version='1.3.0',
    packages=find_packages(),
    include_package_data=True,
    url="http://gitlab-paas.open.oa.com/waylonshi/django-versionlog",
    license='BSD License',  # example license
    description='version log module',
    long_description=README,
    author='blueking',
    author_email='blueking@tencent.com',
    install_requires=[
        'mistune==0.8.4'
    ],
    zip_safe=False,
)
