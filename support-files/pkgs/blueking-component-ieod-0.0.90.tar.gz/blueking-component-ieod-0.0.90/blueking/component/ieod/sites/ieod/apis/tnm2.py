# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTNM2(object):
    """Collections of TNM2 APIS"""

    def __init__(self, client):
        self.client = client

        self.add_alarm_shield_config = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/add_alarm_shield_config/',
            description=u'新增屏蔽策略'
        )
        self.add_alarm_strategy = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/add_alarm_strategy/',
            description=u'新增告警策略的接口'
        )
        self.add_attr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/add_attr/',
            description=u'新增特性'
        )
        self.alarm_shield = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/alarm_shield/',
            description=u'TNM2告警全屏蔽接口'
        )
        self.alarm_shield_by_type = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/alarm_shield_by_type/',
            description=u'TNM2通过告警类型进行告警屏蔽'
        )
        self.alarm_unshield = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/alarm_unshield/',
            description=u'tnm2解屏蔽告警接口'
        )
        self.del_alarm_strategy = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/del_alarm_strategy/',
            description=u'删除告警策略的接口'
        )
        self.del_attr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/del_attr/',
            description=u'删除特性ID'
        )
        self.get_alarm_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_alarm_info/',
            description=u'查询告警信息'
        )
        self.get_alarm_shield_config = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_alarm_shield_config/',
            description=u'查询告警屏蔽策略'
        )
        self.get_alarm_strategy = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_alarm_strategy/',
            description=u'查询告警策略信息'
        )
        self.get_alarm_type = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_alarm_type/',
            description=u'告警类型详细信息查询接口'
        )
        self.get_attr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_attr/',
            description=u'TNM2获取业务特性接口'
        )
        self.get_attr_data = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_attr_data/',
            description=u'获取多台服务器某个特性(1分钟粒度)'
        )
        self.get_attr_group = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_attr_group/',
            description=u'TNM2获取业务特性接口'
        )
        self.get_avg_quality_by_device = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_avg_quality_by_device/',
            description=u'获取交换机链接服务器的丢包和延时数据'
        )
        self.get_batch_attr_value = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_batch_attr_value/',
            description=u'批量拉取单服务器的多个特性值'
        )
        self.get_host_attrs = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_host_attrs/',
            description=u'获取主机特性信息'
        )
        self.get_host_cpu_cnt = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_host_cpu_cnt/',
            description=u'查询CPU核数'
        )
        self.get_idc_by_netidc = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_idc_by_netidc/',
            description=u'根据网络IDC获取IDC'
        )
        self.get_idcs_quality = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_idcs_quality/',
            description=u'查询机房到机房的网络质量'
        )
        self.get_idcspeed_data = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_idcspeed_data/',
            description=u'查询出口质量'
        )
        self.get_service_group_infos_by_idc2 = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_service_group_infos_by_idc2/',
            description=u'获取业务集/IDC流量峰值'
        )
        self.get_summarized_attr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_summarized_attr/',
            description=u'获取叠加特性值'
        )
        self.get_svr_attrs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_svr_attrs/',
            description=u'批量拉取单服务器的多个特性值'
        )
        self.get_svr_disk_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tnm2/get_svr_disk_info/',
            description=u'拉取单服务器的磁盘利用值'
        )
        self.get_svrs_attr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_svrs_attr/',
            description=u'批量拉取多服务器的单一特性值'
        )
        self.get_svrs_disk_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/get_svrs_disk_info/',
            description=u'批量拉取多服务器的磁盘利用值'
        )
        self.update_alarm_strategy = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tnm2/update_alarm_strategy/',
            description=u'更新告警策略的接口'
        )
