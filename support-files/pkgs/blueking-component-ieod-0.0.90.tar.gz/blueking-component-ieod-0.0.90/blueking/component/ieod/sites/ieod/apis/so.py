# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsSO(object):
    """Collections of SO APIS"""

    def __init__(self, client):
        self.client = client

        self.api_get = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/api_get/',
            description=u'查询任务状态'
        )
        self.api_new = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/api_new/',
            description=u'创建任务'
        )
        self.change_hostname = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/change_hostname/',
            description=u'修改主机名'
        )
        self.check_so_job_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/check_so_job_status/',
            description=u'查询任务状态'
        )
        self.config_gcs_dns = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/config_gcs_dns/',
            description=u'配置GCS DNS'
        )
        self.device_available_num = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/device_available_num/',
            description=u'查询空闲可申请机器的数量'
        )
        self.device_recycle = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/device_recycle/',
            description=u'设备回收'
        )
        self.docker_available_num = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/docker_available_num/',
            description=u'查询可生产的Docker容器数量'
        )
        self.get_confcheck_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/get_confcheck_info/',
            description=u'查询配置检查结果信息'
        )
        self.get_job_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/get_job_status/',
            description=u'查询任务状态（ApiService）'
        )
        self.get_pre_deployment_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/get_pre_deployment_result/',
            description=u'查询镜像预部署结果'
        )
        self.get_resizable_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/get_resizable_info/',
            description=u'查询当前可降配镜像信息'
        )
        self.get_resource_num = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/get_resource_num/',
            description=u'获取可以指定机型获取的资源数'
        )
        self.images_list = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/images_list/',
            description=u'查询镜像详细信息'
        )
        self.images_markup = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/images_markup/',
            description=u'给某个镜像打标签'
        )
        self.images_tags = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/images_tags/',
            description=u'查询单个镜像对应的标签详细'
        )
        self.init = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/init/',
            description=u'初始化'
        )
        self.init_check = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/init_check/',
            description=u'配置检查'
        )
        self.install_g3_secagent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_g3_secagent/',
            description=u'安装手游安全agent'
        )
        self.install_gseagent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_gseagent/',
            description=u'安装gseagent'
        )
        self.install_gseagent_dev = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_gseagent_dev/',
            description=u'安装gseagent内测版'
        )
        self.install_l5agent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_l5agent/',
            description=u'安装L5 Agent'
        )
        self.install_ldap = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_ldap/',
            description=u'安装LDAP'
        )
        self.install_ldap_tsso = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_ldap_tsso/',
            description=u'安装TSSO'
        )
        self.install_tsysagent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/install_tsysagent/',
            description=u'安装Tsys Agent'
        )
        self.is_clear = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/is_clear/',
            description=u'空闲检查'
        )
        self.job_build_image = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/job_build_image/',
            description=u'自定义镜像提交'
        )
        self.job_docker_resize = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/job_docker_resize/',
            description=u'Docker容器降配'
        )
        self.job_publish_image = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/job_publish_image/',
            description=u'镜像发布接口'
        )
        self.job_resource_apply = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/job_resource_apply/',
            description=u'自行获取物理机与docker资源'
        )
        self.pods_restart = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/pods_restart/',
            description=u'pod 重启'
        )
        self.proxy_gse_install = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/proxy_gse_install/',
            description=u'安装GseAgent到非IDC专区机器'
        )
        self.query_app_defective_rate = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/query_app_defective_rate/',
            description=u'业务集不达标查询'
        )
        self.query_product_cost = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/query_product_cost/',
            description=u'查询业务的成本信息'
        )
        self.query_svr_flow_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/query_svr_flow_info/',
            description=u'上联交换机流量查询'
        )
        self.recyleip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/recyleip/',
            description=u'回收外网IP'
        )
        self.server_utilization_detail = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/so/server_utilization_detail/',
            description=u'查询服务器利用率'
        )
        self.set_paths_for_build_image = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/set_paths_for_build_image/',
            description=u'设置业务目录白名单'
        )
        self.tcpdump = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/tcpdump/',
            description=u'流量检查'
        )
        self.transfer_ip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/transfer_ip/',
            description=u'IP漂移'
        )
        self.uninstall_g3_secagent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/uninstall_g3_secagent/',
            description=u'卸载安装手游安全agent'
        )
        self.uninstall_gseagent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/uninstall_gseagent/',
            description=u'卸载GseAgent'
        )
        self.up_limit = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/up_limit/',
            description=u'提示ulimit性能'
        )
        self.up_stack_limit = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/up_stack_limit/',
            description=u'提升stack大小'
        )
        self.update_iptables = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/update_iptables/',
            description=u'更新Iptables'
        )
        self.yum_source_update = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/so/yum_source_update/',
            description=u'yum源更新'
        )
