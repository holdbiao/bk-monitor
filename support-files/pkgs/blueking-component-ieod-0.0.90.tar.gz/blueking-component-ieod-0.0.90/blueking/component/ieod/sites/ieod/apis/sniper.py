# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsSNIPER(object):
    """Collections of SNIPER APIS"""

    def __init__(self, client):
        self.client = client

        self.get_all_online_agent = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/sniper/get_all_online_agent/',
            description=u'机房IDCID和名称对应关系查询'
        )
        self.get_ip_quality = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/sniper/get_ip_quality/',
            description=u'服务器网络质量查询'
        )
        self.get_probe_data = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/sniper/get_probe_data/',
            description=u'IDC内网和外网质量接口'
        )
