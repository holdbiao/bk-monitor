# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTOF(object):
    """Collections of TOF APIS"""

    def __init__(self, client):
        self.client = client

        self.send_rtx = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tof/send_rtx/',
            description=u'发送RTX消息'
        )
        self.send_mail = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tof/send_mail/',
            description=u'发送邮件'
        )
        self.send_sms = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tof/send_sms/',
            description=u'发送短信'
        )
        self.send_wx = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tof/send_wx/',
            description=u'发送微信'
        )

        self.get_ad_group_info_by_name = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_ad_group_info_by_name/',
            description=u'获取指定名字的邮件组'
        )
        self.get_all_ad_groups = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_all_ad_groups/',
            description=u'获取所有邮件组列表'
        )
        self.get_all_members_of_ad_groups = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_all_members_of_ad_groups/',
            description=u'获取指定邮件组员工成员列表和邮件组成员列表'
        )
        self.get_child_dept_infos = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_child_dept_infos/',
            description=u'获取子部门信息'
        )
        self.get_dept_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_dept_info/',
            description=u'获取部门信息'
        )
        self.get_dept_staffs_with_level = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_dept_staffs_with_level/',
            description=u'获取部门员工信息'
        )
        self.get_members_of_ad_groups = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_members_of_ad_groups/',
            description=u'获取指定邮件组所归属的邮件组列表'
        )
        self.get_parent_dept_infos = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_parent_dept_infos/',
            description=u'获取父部门信息'
        )
        self.get_staff_direct_leader = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_staff_direct_leader/',
            description=u'根据员工英文名获取员工直属Leader信息'
        )
        self.get_staff_info_by_login_name = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_staff_info_by_login_name/',
            description=u'根据员工英文名获取员工信息'
        )
        self.get_staff_members = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_staff_members/',
            description=u'获取属于指定邮件组的员工列表'
        )
        self.get_unit_principal = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_unit_principal/',
            description=u'获取组织负责人'
        )
        self.get_staff_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_staff_info/',
            description=u'获取员工信息'
        )
        self.get_staff_info_by_name = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tof/get_staff_info_by_name/',
            description=u'根据员工英文名获取员工信息'
        )
