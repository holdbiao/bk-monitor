# -*- coding: utf-8 -*-
"""Django 工程中的变量
"""
import os

from .utils import str_bool

try:
    from django.conf import settings
except Exception:
    settings = None


def get_from_env_or_settings(key, default=None):
    if key in os.environ:
        return os.getenv(key)
    return getattr(settings, key, default)


def get_from_settings(key, default=None):
    return getattr(settings, key, default)


# 如果在 Django 环境下，默认从 settings 中读取配置，否则使用默认配置
APP_CODE = get_from_settings('APP_CODE')
SECRET_KEY = get_from_settings('SECRET_KEY')
RUN_MODE = get_from_settings('RUN_MODE', default='DEVELOP')
DEFAULT_BK_API_VER = get_from_settings('DEFAULT_BK_API_VER', default='v2')

# 优先使用环境变量，如果变量不存在，则从 Django settings 中获取
BK_API_USE_BKCLOUDS_FIRST = str_bool(get_from_env_or_settings('BK_API_USE_BKCLOUDS_FIRST', default=False))
BK_API_USE_TEST_ENV = str_bool(get_from_env_or_settings('BK_API_USE_TEST_ENV', default=False))
