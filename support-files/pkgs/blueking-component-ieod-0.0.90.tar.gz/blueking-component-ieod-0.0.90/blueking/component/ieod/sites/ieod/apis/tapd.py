# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTAPD(object):
    """Collections of TAPD APIS"""

    def __init__(self, client):
        self.client = client

        self.add_baseline = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tapd/add_baseline/',
            description=u'新建基线(Baseline)数据'
        )

        self.add_versions = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tapd/add_versions/',
            description=u'新建版本(Version)数据'
        )

        self.get_baselines = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_baselines/',
            description=u'获取 基线(Baseline)数据'
        )

        self.get_bugs = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_bugs/',
            description=u'获取 缺陷(Bug)数据'
        )

        self.get_iterations = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_iterations/',
            description=u'获取 迭代(Iteration)数据'
        )

        self.get_modules = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_modules/',
            description=u'获取 模块(Module)数据'
        )

        self.get_stories = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_stories/',
            description=u'获取 需求(Story)数据'
        )

        self.get_tcase_categories = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_tcase_categories/',
            description=u'获取 测试用例分类(TcaseCategory)数据'
        )

        self.get_versions = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_versions/',
            description=u'获取 版本(Version)数据'
        )

        self.get_wikis = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_wikis/',
            description=u'获取 wiki 数据'
        )

        self.get_sub_workspaces = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/tapd/get_sub_workspaces/',
            description=u'获取 子项目数据'
        )
