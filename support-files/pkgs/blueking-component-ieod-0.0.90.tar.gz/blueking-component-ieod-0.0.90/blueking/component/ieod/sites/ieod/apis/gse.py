# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsGSE(object):
    """Collections of GSE APIS"""

    def __init__(self, client):
        self.client = client

        self.flush_agent_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/flush_agent_info/',
            description=u'反写Agent信息到gse'
        )
        self.proc_create_session = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/proc_create_session/',
            description=u'新建一个 session'
        )
        self.proc_run_command = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/proc_run_command/',
            description=u'Proc执行命令'
        )
        self.get_agent_status = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_agent_status/',
            description=u'查询Agent状态'
        )
        self.get_alarm = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_alarm/',
            description=u'查询告警'
        )
        self.get_all_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_all_port/',
            description=u'查询所有端口'
        )
        self.get_all_proc = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_all_proc/',
            description=u'查询所有进程'
        )
        self.get_arch = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_arch/',
            description=u'查询Arch'
        )
        self.get_base_report_cfg_v2 = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_base_report_cfg_v2/',
            description=u'获取指定机器基础数据上报配置接口'
        )
        self.get_cpu = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_cpu/',
            description=u'查询CPU'
        )
        self.get_croud = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_croud/',
            description=u'查询Croud'
        )
        self.get_disk = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_disk/',
            description=u'查询磁盘'
        )
        self.get_disk_used = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_disk_used/',
            description=u'查询磁盘占用'
        )
        self.get_history_alarm = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_alarm/',
            description=u'查询历史告警'
        )
        self.get_history_all_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_all_port/',
            description=u'查询历史所有端口'
        )
        self.get_history_all_proc = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_all_proc/',
            description=u'查询历史所有进程'
        )
        self.get_history_arch = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_arch/',
            description=u'查询历史Arch'
        )
        self.get_history_cpu = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_cpu/',
            description=u'查询历史CPU'
        )
        self.get_history_croud = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_croud/',
            description=u'查询历史Croud'
        )
        self.get_history_disk = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_disk/',
            description=u'查询历史磁盘信息'
        )
        self.get_history_disk_used = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_disk_used/',
            description=u'查询历史磁盘占用'
        )
        self.get_history_ip_table = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_ip_table/',
            description=u'查询历史Iptable'
        )
        self.get_history_local_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_local_info/',
            description=u'查询历史本地信息'
        )
        self.get_history_mem = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_mem/',
            description=u'查询历史Mem'
        )
        self.get_history_net = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_net/',
            description=u'查询历史Net'
        )
        self.get_history_process = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_history_process/',
            description=u'查询历史Process'
        )
        self.get_host_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_host_info/',
            description=u'查询机器信息'
        )
        self.get_ip_table = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_ip_table/',
            description=u'查询Iptable'
        )
        self.get_local_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_local_info/',
            description=u'查询本地信息'
        )
        self.get_lost_agent = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_lost_agent/',
            description=u'查询失联Agent'
        )
        self.get_mem = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_mem/',
            description=u'查询Mem'
        )
        self.get_net = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_net/',
            description=u'查询Net'
        )
        self.get_process = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_process/',
            description=u'查询Process'
        )
        self.get_system = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_system/',
            description=u'查询System'
        )
        self.get_task_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_task_info/',
            description=u'查询任务信息'
        )
        self.proc_get_task_result_by_id = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/proc_get_task_result_by_id/',
            description=u'Proc获取任务执行结果'
        )
        self.set_base_report_v2 = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/set_base_report_v2/',
            description=u'开启/关闭 Agent 基础数据采集上报'
        )
        self.update_ip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/update_ip/',
            description=u'更新Agent'
        )
        self.get_update_ip_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gse/get_update_ip_result/',
            description=u'获取更新Agent结果'
        )
        self.copy_file_with_auth = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/copy_file_with_auth/',
            description=u'拷贝文件'
        )
        self.get_copy_file_rst = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gse/get_copy_file_rst/',
            description=u'查询拷贝文件的结果'
        )
