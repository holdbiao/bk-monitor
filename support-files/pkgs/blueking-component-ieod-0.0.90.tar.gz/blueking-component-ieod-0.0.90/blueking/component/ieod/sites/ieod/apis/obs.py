# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsOBS(object):
    """Collections of OBS APIS"""

    def __init__(self, client):
        self.client = client

        self.get_report = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/obs/get_report/',
            description=u'报表接口'
        )
