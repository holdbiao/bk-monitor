# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTOF3(object):
    """Collections of TOF3 APIS"""

    def __init__(self, client):
        self.client = client

        self.check_token = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/tof3/check_token/',
            description=u'验证用户名和token是否匹配有效'
        )
