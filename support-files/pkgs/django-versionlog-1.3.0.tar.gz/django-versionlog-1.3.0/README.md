### 版本日志功能模块v1.3

----

django-versionlog是为网站开发者提供版本日志快速接入的功能模块，支持django框架，兼容python2和python3。开发者只需在项目中进行简单的配置和维护版本日志目录中的md文件，即可在项目中向用户展示网站版本的更新迭代内容。



### Features

----

1. 支持**对话框弹出**和**单页面**两种展示方式

   1. 对话框弹出：可在对应页面弹出对话框展示版本日志更新内容，避免页面跳转，需要在页面进行简单配置，引入相关资源文件并进行相关后端配置。
   2. 单页面：版本日志会跳转到新页面展示，可以避免对已有页面造成影响，只需进行后端配置。提供两种风格的单页面可选：
      * 对话框风格的单页面，适合简单版本日志。
      * 仿gitbook风格的单页面，字号会大一点，适合复杂版本日志。

2. 支持用户新版本日志通知

   当网站发布新版本并更新版本日志后，如果用户没有看过最新版本日志，网站会先跳转到版本日志页面，帮助用户了解新版本特性和功能。

3. 重新设计并支持更多配置项



### Demo

----

- 本页面对话框弹出

   ![dialog](demos/dialog.png)

- 对话框弹出式单页面

   ![dialog-page](demos/dialog-page.png)

- 仿gitbook式单页面

   ![gitbook-page](demos/gitbook-page.png)



### Quick Start

----

本节以单页面对话框版本日志为例，展示使用本功能模块最简单的流程，更多可配置设置请参考Configuation部分：
1. 安装版本日志功能模块(内部仓库)：
    ``` shell
    pip install django-versionlog -i http://pypi.o.tencent.com:8080 --trusted-host pypi.o.tencent.com
    ```

 2. 在项目配置文件中的INSTALLED_APPS内添加version_log：

    ``` python
    INSTALLED_APPS += (
        'home_application',
        'mako_application',
        'version_log'
    )
    ```

 3. 在项目的urls.py中配置路由：

    ```python
    import version_log.config as config
    
    urlpatterns = [
        ...,
        url(r'^{}'.format(config.ENTRANCE_URL), include('version_log.urls', namespace='version_Log')),
    ]
    ```

4. 创建和初始化对应表：

    ```shell
    python manage.py makemigrations version_log
    python manage.py migrate
    ```

5. 启动项目：

    ```shell
    python manage.py runserver
    ```

    项目运行后，会在项目根目录下创建版本日志文件目录version_logs_md，该目录用于存放开发者网站版本日志文件。

    __注意__： 这里假设项目配置变量中BASE_DIR指向工程根目录(如果是蓝鲸开发框架没有修改过则满足该要求)。

6. 添加版本日志文件：

    每个版本的日志对应于一个md文件，同时md文件命名需与版本号对应。
    命名格式可为 `版本号_版本日期.md` 或 `版本号.md`。前者会以文件名中的日期作为版本日期，后者会以文件最新修改日期作为版本日期。
    
    建议版本号的规则满足正则：```[vV](\d+\.){2,4}md```， 如：v1.1.md, V1.2.3.md等，命名风格最好统一。
    版本文件命名中的日期格式可通过FILE_TIME_FORMAT进行配置，默认为`%Y%m%d`，如20201104等。

    开发者需将准备好的版本日志文件都放到version_logs_md文件夹中，1.3.0之后版本模块不再对文件名进行强制校验，所以开发者需保证放入文件夹中的文件都是符合命名规范且可解析的版本日志文件。

7. 重启项目：

    ```shell
    python manage.py runserver
    ```

8. 查看效果：打开链接 `{SITE_URL}/version_log/` 即可查看效果，其中{SITE_URL}为开发者网站地址。



### Configuation

----

__注意__：项目配置文件——django工程为settings.py文件，蓝鲸框架为config/default.py。



#### 必须配置

1. **django 后端配置**
- 本地安装pip install django-versionlog工程tar包，或直接将version_log功能模块文件夹复制到django工程根目录下。
- 本地环境安装pip install mistune包，线上环境需在requirements.txt中添加对应行：mistune==0.8.4。
- 在项目配置文件中的INSTALLED_APPS内添加version_log。
- 在项目urls.py中配置对应的路由，映射到version_log模块自带的urls.py文件，示例：
```python
    import version_log.config as config
    urlpatterns = [
        ...
     	url(r'^{}'.format(config.ENTRANCE_URL), include('version_log.urls', namespace='version_log')),
        ...
    ]
```
- 启动项目前，需要先建用户查看过的版本号信息表：

  ```shell
  python manage.py makemigraions version_log
  python manage.py migtrate
  ```

- 默认情况：

  - version_log模块会在项目首次启动后在根目录下创建version_logs_md和version_logs_html分别用于保存日志文件和日志解析结果，也可提前创建对应文件夹并放入日志文件。
  - version_log只扫描日志文件夹下的日志文件，不会对子文件夹进行递归扫描，每个日志文件对应一个版本。
  - 日志文件命名默认规则为`版本号_版本日期.md`或`版本号.md`，从 1.3.0 开始之后版本不会对文件名进行强校验，建议版本号格式满足`[vV](\d+\.){2,4}md`(如V2.0.1)，日期格式可通过FILE_TIME_FORMAT进行配置，默认为`%Y%m%d`(如20201104)。
  - 日志文件列表展示时按照从大版本号到小版本号排序。

  __注意__：如需自定义日志文件夹路径或日志版本命名格式，详见[自定义配置](#自定义配置)。



2. **html 前端配置**

   **单页面**：不需配置前端，如网站地址为SITE_URL, 则通过SITE_URL/ENTRANCE_URL访问即可，如果没有自定义配置，则ENTRANCE_URL为version_log/，也就是访问SITE_URL/version_log/即可。

   **本页面对话框**：在需要弹出对话框进行页面配置，具体配置如下

- jquery和bootstrap相关资源，version_log包内有提供，示例：
```html
    <!-- Bootstrap css -->
    <link href="https://magicbox.bk.tencent.com/static_api/v3/assets/bootstrap-3.3.4/css/bootstrap.min.css" rel="stylesheet">
    <!-- 如果要使用Bootstrap的js插件，必须先调入jQuery -->
    <script src="https://magicbox.bk.tencent.com/static_api/v3/assets/js/jquery-1.10.2.min.js"></script>
    <!-- 包括所有bootstrap的js插件或者可以根据需要使用的js插件调用　-->
    <script src="https://magicbox.bk.tencent.com/static_api/v3/assets/bootstrap-3.3.4/js/bootstrap.min.js"></script>
```
​	__注意__： 蓝鲸框架中的base.html中已经引入了这几个资源，如果页面继承自base.html，可以不重复引入。

- 其他资源，示例：
```html
	<link href="https://magicbox.bk.tencent.com/static_api/v3/assets/artDialog-6.0.4/css/ui-dialog.css" rel="stylesheet">
	<script src="https://magicbox.bk.tencent.com/static_api/v3/assets/artDialog-6.0.4/dist/dialog-min.js"></script>
```

- 在页面对应位置添加模态框按钮和相关js，其中，window.version_log_url需与urls.py中配置的路由一致，可自行配置, site_url配置为网站域名，蓝鲸框架可直接利用SITE_URL模版变量。示例：
```html
    {% load static %}
    ...
    页面其他内容
    ...
    <button class="king-btn king-info mb15" data-code="2" id="mydialog" onclick="show_modal();">模态对话框</button>
    <script type="text/javascript" src="{% url 'version_log:javascript-catalog' %}"></script>
    <script type="text/javascript">
        function show_modal() {
            load_modal_frame("{% url 'version_log:block' %}");
        }
        
        function load_modal_frame(url) {
            $.ajax({
                url: url,
                type: "GET",
                dataType: "html",
                success: function(data) {
                    var d = dialog({
                        height: 600,
                        width: 1105,
                        title: gettext('版本日志'),
                        content: data,
                    });
                    d.showModal();
                }
            })
        }
        
        // 获取指定的Cookie
        function getCookie(name) {
            var value = "; " + document.cookie;
            var parts = value.split("; " + name + "=");
            if (parts.length === 2) return parts.pop().split(";").shift();
        }
        
        // 如果存在Cookie SHOW_VERSION_LOG值为True，则弹出版本日志弹窗
        if (getCookie("SHOW_VERSION_LOG") === "True") {
            $(document).ready(function () {
                show_modal();
                // 清除Cookie避免重复弹窗
                document.cookie = "SHOW_VERSION_LOG=; path=/; expire=Thu, 01 Jan 1970 00:00:01 GMT;";
            })
        }
    </script>
```

- version_log包内已提供调用所需的所有资源，如果不使用上面的在线资源，可供选择性加载。
```html
    <link rel="stylesheet" href="{% static 'version_log/css/bootstrap.min.css' %}">
    <script src="{% static 'version_log/js/jquery-1.10.2.min.js'%}"></script>
    <script src="{% static 'version_log/js/bootstrap.min.js' %}"></script>
	<link rel="stylesheet" href="{% static 'version_log/css/ui-dialog.css' %}">
    <script src="{% static 'version_log/js/dialog-min.js'%}"></script>
```
​	对于蓝鲸开发框架的模版，上述引用方法还可以用STATIC_URL，如：
```html
	<script src="{% static 'version_log/js/dialog-min.js' %}"></script>
```
​	替换为
```html
    <script src="{{STATIC_URL}}version_log/js/dialog-min.js'"></script>
```



​	**下面提供基于蓝鲸开发框架home_application中home.html嵌入版本日志对话框的一份前端示例代码**

```html
{% extends "base.html" %}

{% block head %}
    <title>蓝鲸开发框架</title>
    {{ block.super }}
{% endblock %}

{% block navigation %}
	<li class="king-navbar-active"><a href="{{ SITE_URL }}"><span>首页</span></a></li>
	<li class=""><a href="{{ SITE_URL }}contact/"><span>联系我们</span></a></li>
{% endblock %}

{% block content %}
	<div>
		<h3>蓝鲸开发框架<small>助力你的自动化</small></h3>
        <button class="king-btn king-info mb15" data-code="2" id="mydialog" onclick="show_modal();">版本日志</button>
	</div>
{% endblock %}

{% block extra_block %}
    <link rel="stylesheet" href="{{STATIC_URL}}version_log/css/ui-dialog.css">
    <script type="text/javascript" src="{% url 'version_log:javascript-catalog' %}"></script>
    <script src="{{STATIC_URL}}version_log/js/dialog-min.js"></script>
    <script type="text/javascript">
        function show_modal() {
            load_modal_frame("{% url 'version_log:block' %}");
        }
        
        function load_modal_frame(url) {
            $.ajax({
                url: url,
                type: "GET",
                dataType: "html",
                success: function(data) {
                    var d = dialog({
                        height: 600,
                        width: 1105,
                        title: gettext('版本日志'),
                        content: data,
                    });
                    d.showModal();
                }
            })
        }
        
        // 获取指定的Cookie
        function getCookie(name) {
            var value = "; " + document.cookie;
            var parts = value.split("; " + name + "=");
            if (parts.length === 2) return parts.pop().split(";").shift();
        }
        
        // 如果存在Cookie SHOW_VERSION_LOG值为True，则弹出版本日志弹窗
        if (getCookie("SHOW_VERSION_LOG") === "True") {
            $(document).ready(function () {
                show_modal();
                // 清除Cookie避免重复弹窗
                document.cookie = "SHOW_VERSION_LOG=; path=/; expire=Thu, 01 Jan 1970 00:00:01 GMT;";
            })
        }
    </script>
{% endblock %}
```



#### 自定义配置

自定义配置项可在项目配置文件中配置，以下是默认配置，自定义配置只需要选择需要修改项进行对应配置重置。

```python
# 默认设置
VERSION_LOG = {
    'MD_FILES_DIR': 'version_logs_md',
    'NAME_PATTERN': '[vV](\d+\.){2,4}md',
    'FILE_TIME_FORMAT': '%Y%m%d',
    'LATEST_VERSION_INFORM': False,
    'LATEST_VERSION_INFORM_TYPE': 'redirect',
    'ENTRANCE_URL': 'version_log/',
    'PAGE_HEAD_TITLE': '版本日志',
    'PAGE_STYLE': 'dialog',
    'USE_HASH_URL': True
}
```

- MD_FILES_DIR：版本日志md文件夹，默认情况下会在第一次项目启动时创建version_logs_md文件夹，也可自己创建并把版本日志文件添加进去。如需自定义，请修改文件夹名称并确保自定义文件夹已创建。

- NAME_PATTERN：版本日志文件命名匹配规则，需是正则表达式。（1.3.0 版本之后不做强制校验）

- FILE_TIME_FORMAT: 版本日志文件命名中日期格式，默认为`%Y%m%d`，需为time.strptime支持的格式

- LATEST_VERSION_INFORM：最新版本通知开关

  如果需要开启自动版本通知，除了将该配置设为True，还需要在项目配置文件中添加对应的中间件：

  ```python
  'version_log.middleware.VersionLogMiddleware'
  ```

  当有新版本日志时，符合以下条件的请求会触发自动版本通知。

  1. 请求方法为GET
  2. 返回页面的Content-Type包含 `text/html`
  3. 返回页面的状态码为200
  4. 请求的用户没被通知过

  通知的方式有两种:

  1. popup，弹窗模式，会在原应用会自动调用show_modal方法
  2. redirect ，页面会被重定向到版本日志页面

  __注意__：开发者功能测试时，添加新版日志文件后需要重启项目进程。基于性能考虑，这里假设正常发布新版本时都会重启项目进程同时添加版本日志文件，所以只会在启动项目时获取一次最新版本号。

- LATEST_VERSION_INFORM_TYPE: 最新版本通知方式(popup/redirect)

- ENTRANCE_URL: version_log模块入口url配置，开发者可自定义一个入口url，用于展示版本日志页面和相关请求，变量为以"/"结尾的字符串。修改这一项的话，需要在本页面对话框的前端配置中将window.version_log_url和在单页面将跳转链接设置为对应的模块入口路径。

- PAGE_HEAD_TITLE：单页面版本日志展示时的标签题目，可以配合开发者网站进行自定义。

- PAGE_STYLE：单页面版本日志的风格选择，默认为对话框单页面，也可改为'gitbook'选择仿gitbook风格单页面。

- USE_HASH_URL: 前端 url 的形式, 默认使用 hash, 类如: /#/index 的路由, 如果是 history 形式,可设置为 False, 获取不到默认为空.

### 自动跳转功能设置

### 装饰器控制方式
  
通过给视图函数添加装饰器, 在刷新页面或者重新打开页面后,会自动跳转到更新日志查看页面(注意 URL 格式, 默认为 hash, 可设置)

具体设置方法如:

```python
from version_log.decorators import update_log_view

# 访问 / 时会检查用户访问历史版本, 有更新会跳转
@update_log_view
def home(request):
    return render(request, settings.INDEX_TEMPLATE, {})

### Support 

- 对于蓝鲸开发框架open版本（社区版和企业版），如果遇到静态文件请求404问题，则部署前需要手动将静态文件打包到static文件夹。

  可以先在config/dev.py中设置STATIC_ROOT路径存放打包文件，示例：
  
  ```python 
STATIC_ROOT = os.path.join(BASE_DIR, 'new_static')
  ```

  然后命令行运行进行静态文件打包
  
  ```shell
python manage.py collectstatic
  ```
  
  最后将new_static文件夹中version_log的对应静态文件夹复制到static文件夹即可。（new_static文件夹可删除，dev.py中的代码可删除）