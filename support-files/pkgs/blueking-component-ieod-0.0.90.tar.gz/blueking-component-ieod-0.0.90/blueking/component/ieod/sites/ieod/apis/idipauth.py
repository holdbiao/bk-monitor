# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIDIPAUTH(object):
    """Collections of IDIPAUTH APIS"""

    def __init__(self, client):
        self.client = client

        self.get_app_areas = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/idipauth/get_app_areas/',
            description=u'查询指定cc_id所有包含的大区'
        )
        self.get_conf_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idipauth/get_conf_info/',
            description=u'查询db dr信息'
        )
        self.get_db_type_conf = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idipauth/get_db_type_conf/',
            description=u'查询大区配置对应关系'
        )
        self.get_history_log = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idipauth/get_history_log/',
            description=u'查询历史记录'
        )
