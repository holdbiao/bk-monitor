# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsSMCS(object):
    """Collections of SMCS APIS"""

    def __init__(self, client):
        self.client = client

        self.send_sms = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/smcs/send_sms/',
            description=u'发送短信'
        )

        self.send_weixin = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/smcs/send_weixin/',
            description=u'发送微信'
        )

        self.sms_approve_api = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/smcs/sms_approve_api/',
            description=u'短信审批'
        )

        self.wechat_approve_api = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/smcs/wechat_approve_api/',
            description=u'微信审批'
        )
