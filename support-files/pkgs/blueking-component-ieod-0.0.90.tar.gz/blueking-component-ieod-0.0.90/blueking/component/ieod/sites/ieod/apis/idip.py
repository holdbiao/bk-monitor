# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIDIP(object):
    """Collections of IDIP APIS"""

    def __init__(self, client):
        self.client = client

        self.send_cmd = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/idip/send_cmd/',
            description=u'发送指令'
        )

        self.gm_cmd = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/idip/gm_cmd/',
            description=u'发送GM指令'
        )
