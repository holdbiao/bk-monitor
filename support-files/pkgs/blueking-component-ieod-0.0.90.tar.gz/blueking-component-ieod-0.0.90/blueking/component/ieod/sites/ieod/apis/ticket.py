# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsTICKET(object):
    """Collections of TICKET APIS"""

    def __init__(self, client):
        self.client = client

        self.search_by_bulletin = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ticket/search_by_bulletin/',
            description=u'TICKET公告单查询接口'
        )
