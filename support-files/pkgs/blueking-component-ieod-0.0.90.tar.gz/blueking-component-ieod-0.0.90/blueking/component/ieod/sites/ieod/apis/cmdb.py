# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsCMDB(object):
    """Collections of CMDB APIS"""

    def __init__(self, client):
        self.client = client

        self.get_query_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/get_query_info/',
            description=u'cmdb通用查询'
        )

        self.config_modify = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/config_modify/',
            description=u'配置信息修改'
        )

        self.svr_operation_mod_operation_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_operation_mod_operation_info/',
            description=u'修改服务器基本信息'
        )
        self.svr_busi_update_svr_busi = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_busi_update_svr_busi/',
            description=u'更新服务器业务信息'
        )
        self.svr_busi_add_svr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_busi_add_svr/',
            description=u'添加主机业务模块'
        )
        self.svr_busi_update_svr = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_busi_update_svr/',
            description=u'更新主机业务模块'
        )
        self.svr_port_add_svr_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_port_add_svr_port/',
            description=u'新增服务器端口'
        )
        self.svr_port_delbatch_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_port_delbatch_port/',
            description=u'批量删除服务器端口'
        )
        self.svr_port_mod_svr_port = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_port_mod_svr_port/',
            description=u'调整服务器端口'
        )
        self.svr_proc_add_svr_proc = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_proc_add_svr_proc/',
            description=u'新增服务器进程'
        )
        self.svr_proc_delbatch_proc = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_proc_delbatch_proc/',
            description=u'批量删除服务器进程'
        )
        self.svr_proc_mod_svr_proc = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/cmdb/svr_proc_mod_svr_proc/',
            description=u'调整服务器进程'
        )
