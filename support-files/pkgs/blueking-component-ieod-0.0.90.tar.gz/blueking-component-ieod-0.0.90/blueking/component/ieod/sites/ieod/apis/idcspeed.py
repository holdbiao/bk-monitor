# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIDCSPEED(object):
    """Collections of IDCSPEED APIS"""

    def __init__(self, client):
        self.client = client

        self.get_agent_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_agent_info/',
            description=u'Agent配置查询接口'
        )
        self.get_avg_delay_by_ip = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_avg_delay_by_ip/',
            description=u'平均延时查询接口'
        )
        self.get_china_zone_quality = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_china_zone_quality/',
            description=u'国内用户质量概览接口'
        )
        self.get_country_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_country_info/',
            description=u'国家编码查询接口'
        )
        self.get_isp_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_isp_info/',
            description=u'运营商编码查询接口'
        )
        self.get_prov_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_prov_info/',
            description=u'地区编码查询接口'
        )
        self.get_speed_data = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/idcspeed/get_speed_data/',
            description=u'原始数据接口'
        )
