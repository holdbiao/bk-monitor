# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsJOB(object):
    """Collections of JOB APIS"""

    def __init__(self, client):
        self.client = client

        self.change_cron_status = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/change_cron_status/',
            description=u'更新定时作业状态'
        )
        self.copy_file_with_auth = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/copy_file_with_auth/',
            description=u'异步文件拷贝'
        )
        self.do_step_operation = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/do_step_operation/',
            description=u'步骤操作'
        )
        self.execute_dial_test = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/execute_dial_test/',
            description=u'启动拨测任务'
        )
        self.execute_platform_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/execute_platform_task/',
            description=u'启动平台作业'
        )
        self.execute_task = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/execute_task/',
            description=u'根据作业模板ID启动作业'
        )
        self.execute_task_ext = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/execute_task_ext/',
            description=u'启动作业Ext(带全局变量启动)'
        )
        self.fast_execute_script = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/fast_execute_script/',
            description=u'快速执行脚本'
        )
        self.fast_push_file = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/fast_push_file/',
            description=u'快速分发文件'
        )
        self.get_all_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_all_application/',
            description=u'查询所有业务列表'
        )
        self.get_all_host_proc_state_by_user = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/get_all_host_proc_state_by_user/',
            description=u'查询GSE进程托管状态'
        )
        self.get_cron = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_cron/',
            description=u'查询业务下定时作业信息'
        )
        self.get_file_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_file_result/',
            description=u'查询GSE获取文件结果'
        )
        self.get_os_account = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_os_account/',
            description=u'查询业务下的执行账号'
        )
        self.get_proc_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_proc_result/',
            description=u'查询GSE进程托管结果'
        )
        self.get_script_detail = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_script_detail/',
            description=u'查询脚本详情'
        )
        self.get_script_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_script_list/',
            description=u'查询脚本列表'
        )
        self.get_step_execute_detail = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_step_execute_detail/',
            description=u'查看步骤执行详情'
        )
        self.get_task = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task/',
            description=u'查询所有作业模板'
        )
        self.get_task_detail = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_detail/',
            description=u'查询作业模板详情'
        )
        self.get_task_execution_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_execution_result/',
            description=u'查询作业执行历史'
        )
        self.get_task_instance = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_instance/',
            description=u'根据作业模版查询作业实例'
        )
        self.get_task_instance_detail = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_instance_detail/',
            description=u'根据作业实例ID查询作业实例详情'
        )
        self.get_task_ip_log = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_ip_log/',
            description=u'根据作业实例ID查询作业执行日志'
        )
        self.get_task_result = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_result/',
            description=u'根据作业实例 ID 查询作业执行状态'
        )
        self.get_task_result_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/get_task_result_list/',
            description=u'根据作业实例ID, 查看作业执行状态'
        )
        self.gse_get_copy_file_rst = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/gse_get_copy_file_rst/',
            description=u'获取分发文件进度结果'
        )
        self.gse_get_file = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/gse_get_file/',
            description=u'GSE 获取文件接口'
        )
        self.gse_get_push_file_v2_rst = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/job/gse_get_push_file_v2_rst/',
            description=u'获取GsePushFileV2文件进度'
        )
        self.gse_proc_operate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/gse_proc_operate/',
            description=u'GSE 进程操作'
        )
        self.gse_proc_operate_v3 = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/gse_proc_operate_v3/',
            description=u'GSE 进程操作-V3版本'
        )
        self.gse_process_manage = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/gse_process_manage/',
            description=u'GSE进程托管注册和取消注册'
        )
        self.gse_push_file = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/gse_push_file/',
            description=u'GSE 文件内容推送'
        )
        self.gse_push_file_v2 = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/gse_push_file_v2/',
            description=u'GSE 文件内容推送V2'
        )
        self.operate_job_instance = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/operate_job_instance/',
            description=u'操作作业实例'
        )
        self.poll_check_task_result = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/poll_check_task_result/',
            description=u'轮询JOB执行实例的状态'
        )
        self.refresh_agent_status = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/refresh_agent_status/',
            description=u'刷新Agent状态'
        )
        self.save_cron = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/job/save_cron/',
            description=u'新建或保存定时作业'
        )
