# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsMMWSD(object):
    """Collections of MMWSD APIS"""

    def __init__(self, client):
        self.client = client

        self.get_curve_page_data = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/mmwsd/get_curve_page_data/',
            description=u'获取曲线表格数据'
        )
