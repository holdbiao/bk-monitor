# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsREL2(object):
    """Collections of REL2 APIS"""

    def __init__(self, client):
        self.client = client

        self.change_accept = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/change_accept/',
            description=u'发布变更系统变更受理接口'
        )
        self.change_apply = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/change_apply/',
            description=u'发布变更系统变更申请接口'
        )
        self.change_effectiveness = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/change_effectiveness/',
            description=u'发布变更系统变更总结接口'
        )
        self.details = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/rel2/details/',
            description=u'发布系统单据信息接口'
        )
        self.effectiveness = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/effectiveness/',
            description=u'发布系统发布总结接口'
        )
        self.evaluate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/evaluate/',
            description=u'发布系统运维协调接口'
        )
        self.get_type_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/rel2/get_type_list/',
            description=u'获取标准化工具任务类型列表'
        )
        self.rel_apply = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/rel_apply/',
            description=u'发布申请'
        )
        self.search = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/search/',
            description=u'发布系统通用查询接口'
        )
        self.standard_task_cancel = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/standard_task_cancel/',
            description=u'标准化工具取消关联接口'
        )
        self.standard_task_finish = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/standard_task_finish/',
            description=u'标准化工具完结'
        )
        self.standard_task_plan = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/standard_task_plan/',
            description=u'标准化工具计划提报'
        )
        self.standard_task_relate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/standard_task_relate/',
            description=u'标准化工具关联接口(上报执行计划)'
        )
        self.standard_task_update = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/standard_task_update/',
            description=u'标准化工具关键信息更新'
        )
        self.test_confirm = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/test_confirm/',
            description=u'测试确认接口'
        )
        self.todo = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/rel2/todo/',
            description=u'发布系统通用待办接口'
        )
        self.common_list = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/common_list/',
            description=u'发布系统通用列表接口'
        )
        self.bind_itest_rel = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/rel2/bind_itest_rel/',
            description=u'绑定itest到rel2'
        )
