# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsIMONITOR(object):
    """Collections of IMONITOR APIS"""

    def __init__(self, client):
        self.client = client

        self.get_imonitor_attr_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/imonitor/get_imonitor_attr_id/',
            description=u'获取监控特性ID'
        )
