# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsGCS(object):
    """Collections of GCS APIS"""

    def __init__(self, client):
        self.client = client

        self.alter_bill = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/alter_bill/',
            description=u'GCS变更提单'
        )
        self.alter_bill_by_ddl = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/alter_bill_by_ddl/',
            description=u'根据sql语句变更提单'
        )
        self.auto_db_migrate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/auto_db_migrate/',
            description=u'指定DB迁移提单'
        )
        self.bill_execute = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/bill_execute/',
            description=u'GCS变更单据执行'
        )
        self.check_app_cnt_zone = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/check_app_cnt_zone/',
            description=u'按IDC查询业务是否可开指定数量的大区'
        )
        self.check_bill_audit = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/check_bill_audit/',
            description=u'GCS单据状态查询'
        )
        self.check_service_status = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/check_service_status/',
            description=u'检查服务状态'
        )
        self.checksum = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/checksum/',
            description=u'GCS数据校验提单'
        )
        self.common_query = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/common_query/',
            description=u'GCS通用查询'
        )
        self.complex_open_zone = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/complex_open_zone/',
            description=u'复合开区'
        )
        self.db_backup = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/db_backup/',
            description=u'MYSQL备份'
        )
        self.dbalter_dml = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/dbalter_dml/',
            description=u'变更(数据修改)'
        )
        self.get_app_dbas = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_app_dbas/',
            description=u'查询主/备份DBA'
        )
        self.get_app_new_zone_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_app_new_zone_info/',
            description=u'查询指定业务各个IDC可开新区的数量列表'
        )
        self.get_db_app_name = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_db_app_name/',
            description=u'获取DB业务缩写'
        )
        self.get_domain_info_by_id = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/get_domain_info_by_id/',
            description=u'Redis开区查询'
        )
        self.get_input_role = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_input_role/',
            description=u'GCS开区完整参数查询'
        )
        self.get_input_role_for_spider = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_input_role_for_spider/',
            description=u'查询开区参数'
        )
        self.get_input_role_kiri = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_input_role_kiri/',
            description=u'GCS凯丽开区参数查询'
        )
        self.get_ipinfo_from_gcs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/get_ipinfo_from_gcs/',
            description=u'检测主机是否存在于GCS系统'
        )
        self.get_mssql_query_task = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_mssql_query_task/',
            description=u'获取mssql_query可执行的任务列表'
        )
        self.get_new_host = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/get_new_host/',
            description=u'查找符合条件的空闲机'
        )
        self.get_slow_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_slow_info/',
            description=u'GCS 查询慢查询信息'
        )
        self.get_spes = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_spes/',
            description=u'获取系统性能数据'
        )
        self.get_spider_zone_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_spider_zone_list/',
            description=u'查询一个业务的子群已开区'
        )
        self.get_spider_zone_num = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_spider_zone_num/',
            description=u'查询一个业务的集群可开区数'
        )
        self.get_todo_schedule = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcs/get_todo_schedule/',
            description=u'查询待办事项'
        )
        self.instance_decommission = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/instance_decommission/',
            description=u'GCS实例下架'
        )
        self.instance_transfer = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/instance_transfer/',
            description=u'GCS实例迁移提单'
        )
        self.migrate_data = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/migrate_data/',
            description=u'GCS数据搬迁'
        )
        self.mssql_query = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/mssql_query/',
            description=u'SqlServer自定义指令查询'
        )
        self.mysql_privileges = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/mysql_privileges/',
            description=u'MYSQL权限申请'
        )
        self.new_host = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/new_host/',
            description=u'GCS主机上架'
        )
        self.new_host_check = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/new_host_check/',
            description=u'GCS主机上架检测'
        )
        self.open_zone = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/open_zone/',
            description=u'GCS自助开区'
        )
        self.open_zone_kiri = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/open_zone_kiri/',
            description=u'凯丽自助开区'
        )
        self.priv_revoke = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/priv_revoke/',
            description=u'权限回收提单'
        )
        self.privileges_clone_client = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/privileges_clone_client/',
            description=u'GCS权限克隆'
        )
        self.rename_db = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/rename_db/',
            description=u'GCS数据库重命名'
        )
        self.spider_alter_bill = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_alter_bill/',
            description=u'GCS系统变更提单'
        )
        self.spider_alter_bill_for_test = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_alter_bill_for_test/',
            description=u'GCS系统变更提单接口(仅供开发使用)'
        )
        self.spider_dbalter_ddl = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_dbalter_ddl/',
            description=u'Spider-DDL变更'
        )
        self.spider_dbalter_dml = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_dbalter_dml/',
            description=u'Spider变更(数据修改)'
        )
        self.spider_dbbackup = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_dbbackup/',
            description=u'Spider库表备份提单'
        )
        self.spider_open_zone = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_open_zone/',
            description=u'spider自助开区'
        )
        self.spider_truncate_data = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/spider_truncate_data/',
            description=u'Spider自助清档'
        )
        self.sqlserver_alter_bill = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/sqlserver_alert_bill/',
            description=u'sqlserver变更提单'
        )
        self.tredis_cache_backup = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_cache_backup/',
            description=u'Tendis cache-备份'
        )
        self.tredis_cache_del_keys_by_patten = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_cache_del_keys_by_patten/',
            description=u'删除cache集群KEYS'
        )
        self.tredis_cache_flushdata = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_cache_flushdata/',
            description=u'Tendis cache-自助清档'
        )
        self.tredis_cache_get_keys_by_patten = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_cache_get_keys_by_patten/',
            description=u'提取cache集群KEYS'
        )
        self.tredis_ssd_backup = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_ssd_backup/',
            description=u'Tendis ssd-备份'
        )
        self.tredis_ssd_del_keys_by_patten = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_ssd_del_keys_by_patten/',
            description=u'删除ssd集群KEYS'
        )
        self.tredis_ssd_flushdata = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_ssd_flushdata/',
            description=u'Tendis ssd-自助清档'
        )
        self.tredis_ssd_get_keys_by_patten = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/tredis_ssd_get_keys_by_patten/',
            description=u'提取ssd集群KEYS'
        )
        self.truncate_data = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/truncate_data/',
            description=u'GCS自助清档接口'
        )
        self.truncate_data_new = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcs/truncate_data_new/',
            description=u'GCS自助清档接口'
        )
