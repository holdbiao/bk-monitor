# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsWEIXIN(object):
    """Collections of WEIXIN APIS"""

    def __init__(self, client):
        self.client = client

        self.wechat_approve = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/weixin/wechat_approve/',
            description=u'微信审批接口'
        )
        self.send_weixin = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/weixin/send_weixin/',
            description=u'微信发送接口'
        )
        self.sms_approve = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/weixin/sms_approve_api/',
            description=u'短信审批接口'
        )
