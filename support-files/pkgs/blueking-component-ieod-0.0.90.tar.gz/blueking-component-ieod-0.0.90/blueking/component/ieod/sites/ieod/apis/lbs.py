# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsLBS(object):
    """Collections of LBS APIS"""

    def __init__(self, client):
        self.client = client

        self.get_ip_info = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/lbs/get_ip_info/',
            description=u'获取主机信息'
        )
