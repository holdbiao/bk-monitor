# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsAMS(object):
    """Collections of AMS APIS"""

    def __init__(self, client):
        self.client = client

        self.gameattr_sidip = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/ams/gameattr_sidip/',
            description=u'安全IDIP接口调用'
        )
