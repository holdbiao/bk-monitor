# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsSTGW(object):
    """Collections of STGW APIS"""

    def __init__(self, client):
        self.client = client

        self.apply_l7_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/apply_l7_rule/',
            description=u'申请7层负载均衡规则'
        )
        self.get_certificate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/get_certificate/',
            description=u'获取证书'
        )
        self.get_l7_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/get_l7_rule/',
            description=u'查询规则'
        )
        self.get_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/get_rs/',
            description=u'获取规则的RS信息'
        )
        self.op_l7_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/op_l7_rs/',
            description=u'增加或删除7层RS'
        )
        self.set_l7_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/set_l7_rule/',
            description=u'修改7层负载均衡规则'
        )
        self.update_l7_rs = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/stgw/update_l7_rs/',
            description=u'RS上下线及权重修改'
        )
