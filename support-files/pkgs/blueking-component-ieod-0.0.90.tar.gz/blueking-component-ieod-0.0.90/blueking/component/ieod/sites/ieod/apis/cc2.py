# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsCC2(object):
    """collections of CC2 APIS"""

    def __init__(self, client):
        self.client = client

        # Query
        self.check_user_role = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/check_user_role/',
            description=u'校验用户属于某个角色'
        )
        self.get_app_by_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_app_by_id/',
            description=u'根据id获取业务信息'
        )
        self.get_app_by_user_role = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_app_by_user_role/',
            description=u'根据用户角色获取业务'
        )
        self.get_app_by_user = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_app_by_user/',
            description=u'根据用户获取业务'
        )
        self.get_app_host_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_app_host_list/',
            description=u'查询业务主机列表'
        )
        self.get_app_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_app_list/',
            description=u'获取应用列表'
        )
        self.get_host_list_by_ip = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_host_list_by_ip/',
            description=u'根据ip查询主机信息'
        )
        self.get_module_host_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_module_host_list/',
            description=u'查询模块主机列表'
        )
        self.get_modules = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_modules/',
            description=u'查询模块列表'
        )
        self.get_modules_by_app_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_modules_by_app_id/',
            description=u'根据业务ID查询模块信息'
        )
        self.get_property_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_property_list/',
            description=u'获取属性列表'
        )
        self.get_set_property = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_set_property/',
            description=u'查询set属性'
        )
        self.get_hosts_by_property = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_hosts_by_property/',
            description=u'根据set属性查询主机'
        )
        self.get_sets_by_property = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_sets_by_property/',
            description=u'根据set属性获取sets'
        )
        self.get_topo_tree_by_app_id = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/cc2/get_topo_tree_by_app_id/',
            description=u'查询业务拓扑结构'
        )
