# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsODM(object):
    """Collections of ODM APIS"""

    def __init__(self, client):
        self.client = client

        self.add_server = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/odm/add_server/',
            description=u'ODM部署开区'
        )
        self.download_sql_file = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/odm/download_sql_file/',
            description=u'下载生成的sql文件'
        )
        self.generate_mysql = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/odm/generate_mysql/',
            description=u'进行比较，生成sql'
        )
        self.get_application = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/odm/get_application/',
            description=u'获取ODM业务列表'
        )
        self.get_xml_list = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/odm/get_xml_list/',
            description=u'获取XML文件列表'
        )
        self.gray_publish = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/odm/gray_publish/',
            description=u'灰度发布'
        )
        self.upload_result = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/odm/upload_result/',
            description=u'提交对比结果'
        )
        self.upload_xml_file = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/odm/upload_xml_file/',
            description=u'上传XML文件'
        )
