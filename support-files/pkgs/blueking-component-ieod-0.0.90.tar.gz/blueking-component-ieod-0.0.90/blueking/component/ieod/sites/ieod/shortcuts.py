# -*- coding: utf-8 -*-
from .conf import oauth_client

from ...utils import get_client_ip
from ...client import ComponentClient
from ... import conf

import logging
logger = logging.getLogger('component')

__all__ = [
    'get_client_by_request',
    'get_client_by_user',
]


def get_client_by_request(request, **kwargs):
    """根据当前请求返回一个client

    :param request: 一个django request实例
    :returns: 一个初始化好的ComponentClint对象
    """

    username = ''
    access_token = ''
    is_authenticated = request.user.is_authenticated
    if callable(is_authenticated):
        is_authenticated = is_authenticated()
    if is_authenticated:
        username = request.user.username

        # 新的access_token
        if oauth_client.is_enabled:
            try:
                access_token_obj = oauth_client.get_access_token(request)
                access_token = access_token_obj.access_token
            except Exception:
                logger.exception(u"bkoauth 根据user（%s）获取 access_token 失败" % username)

    common_args = {
        'operator': username,
        'bk_ticket': request.COOKIES.get('bk_ticket', ''),
        'oa_ticket': request.session.get('ticket') or request.GET.get('ticket', ''),
        'bk_client_ip': get_client_ip(request),
        'access_token': access_token,
    }
    common_args.update(kwargs)
    return ComponentClient(conf.APP_CODE, conf.SECRET_KEY, common_args=common_args)


def get_client_by_user(user, **kwargs):
    """根据user实例返回一个client

    :param user: User实例或者User.username数据
    :returns: 一个初始化好的ComponentClint对象
    """
    access_token = ''
    username = getattr(user, 'username', user)

    if oauth_client.is_enabled:
        try:
            # 新的access_token，会自动根据refresh_token刷新
            access_token_obj = oauth_client.get_access_token_by_user(username)
            access_token = access_token_obj.access_token
        except Exception:
            logger.exception(u"根据user（%s）获取access_token失败，请检查 bkoauth 配置" % user)

    common_args = {'access_token': access_token, 'operator': username}
    common_args.update(kwargs)
    return ComponentClient(conf.APP_CODE, conf.SECRET_KEY, common_args=common_args)
