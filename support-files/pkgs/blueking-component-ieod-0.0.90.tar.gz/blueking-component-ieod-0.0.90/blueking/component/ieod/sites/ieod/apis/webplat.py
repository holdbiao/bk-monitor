# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsWEBPLAT(object):
    """Collections of WEBPLAT APIS"""

    def __init__(self, client):
        self.client = client

        self.add_alarm_info = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/add_alarm_info/',
            description=u'发送自助停服通告'
        )
        self.game_area_create = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/game_area_create/',
            description=u'新建大区和区服接口'
        )
        self.game_area_custom = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/game_area_custom/',
            description=u'区服自定义属性变更'
        )
        self.game_area_info_query = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/webplat/game_area_info_query/',
            description=u'查询区服信息接口'
        )
        self.game_area_operate = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/game_area_operate/',
            description=u'批量运营及停机接口'
        )
        self.game_area_publish = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/game_area_publish/',
            description=u'测试发布与正式发布接口'
        )
        self.game_area_query = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/webplat/game_area_query/',
            description=u'查询业务下大区列表接口'
        )
        self.game_area_update = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/game_area_update/',
            description=u'区服信息更新接口'
        )
        self.game_dir_info_query = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/webplat/game_dir_info_query/',
            description=u'查询区服的大区信息接口'
        )
        self.game_dir_update = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/game_dir_update/',
            description=u'大区信息更新接口'
        )
        self.game_service_info_query = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/webplat/game_service_info_query/',
            description=u'查询业务列表接口'
        )
        self.get_ip_recommend = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/webplat/get_ip_recommend/',
            description=u'当前IP推荐服查询接口'
        )
        self.set_ip_recommend = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/set_ip_recommend/',
            description=u'IP推荐管理设置为当前推荐'
        )
        self.set_server_number = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/set_server_number/',
            description=u'设置单独服务器最大在线人数、最大注册人数接口'
        )
        self.set_top = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/webplat/set_top/',
            description=u'大区置顶设置接口'
        )
