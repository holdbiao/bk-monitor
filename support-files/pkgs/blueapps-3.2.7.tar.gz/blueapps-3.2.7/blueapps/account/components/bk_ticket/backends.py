# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

import logging

from django.contrib.auth.backends import ModelBackend

from blueapps.account import get_user_model
from blueapps.account.conf import ConfFixture
from blueapps.account.utils.http import send

logger = logging.getLogger('component')


class TicketBackend(ModelBackend):
    def authenticate(self, request=None, bk_ticket=None):
        logger.debug(u"进入 Paas 认证 Backend")
        if not bk_ticket:
            return None

        result, user_info = self.verify_bk_ticket(bk_ticket)
        if not result:
            return None

        user_model = get_user_model()
        user, _ = user_model.objects.get_or_create(
            username=user_info['username'])
        user.nickname = user_info['username']
        user.avatar_url = user_info['avatar_url']
        user.save()
        return user

    @staticmethod
    def verify_bk_ticket(bk_ticket):
        """
        验证 OA 登录票据
        @param {string} bk_ticket OA 登录票据
        @return {tuple} ret
        @return {boolean} ret[0] 是否认证通过
        @return {dict} ret[1] 当 result=True，该字段为用户信息，举例
            {
                'username': 'jeremylv',
                'avatar_url': 'http://???.??.com/avatars/jeremylv/avatar.jpg'
            }
        """
        api_params = {
            'bk_ticket': bk_ticket
        }
        try:
            response = send(ConfFixture.USER_INFO_URL, 'GET', api_params)
            ret = response.get('ret')

            if ret == 0:
                return True, response['data']
            else:
                logger.error(u"bk_ticket 验证失败，error={}，ret={}".format(
                    response['msg'], ret))
                return False, None
        except Exception:
            logger.exception(u"bk_ticket 验证异常")
            return False, None
