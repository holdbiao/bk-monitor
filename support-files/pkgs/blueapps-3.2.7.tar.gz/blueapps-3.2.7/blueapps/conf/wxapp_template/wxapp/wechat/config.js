module.exports = {
  RIO_URL: '填写RIO外网网址',
  RIO_APP: "填写您在RIO申请的KEY",
  BK_PATH: "/wxapp",
  DEBUG: false
}
