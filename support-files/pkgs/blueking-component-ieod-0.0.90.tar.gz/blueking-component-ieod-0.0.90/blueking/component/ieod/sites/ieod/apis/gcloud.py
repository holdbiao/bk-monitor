# -*- coding: utf-8 -*-
from ....base import ComponentAPI


class CollectionsGCLOUD(object):
    """Collections of GCLOUD APIS"""

    def __init__(self, client):
        self.client = client

        self.batch_update_node = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/batch_update_node/',
            description=u'批量更新区服节点'
        )
        self.create_node = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/create_node/',
            description=u'创建区服节点'
        )
        self.create_platform = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/create_platform/',
            description=u'创建大区'
        )
        self.get_all_gray_rule = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcloud/get_all_gray_rule/',
            description=u'获取所有灰度规则'
        )
        self.get_upload_task = ComponentAPI(
            client=self.client, method='GET', path='/component/compapi/gcloud/get_upload_task/',
            description=u'查询版本上传CDN任务状态'
        )
        self.import_tree = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/import_tree/',
            description=u'导入正式环境/预发布环境区服树'
        )
        self.new_app = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/new_app/',
            description=u'创建单个版本'
        )
        self.new_product = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/new_product/',
            description=u'创建渠道'
        )
        self.new_res = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/new_res/',
            description=u'创建资源版本'
        )
        self.new_user_list_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/new_user_list_rule/',
            description=u'创建白名单灰度策略'
        )
        self.new_world_list_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/new_world_list_rule/',
            description=u'创建区服灰度策略'
        )
        self.pre_publish = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/pre_publish/',
            description=u'预发布单个大区'
        )
        self.pre_publish_product = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/pre_publish_product/',
            description=u'预发布单个渠道'
        )
        self.publish = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/publish/',
            description=u'正式发布单个大区'
        )
        self.publish_product = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/publish_product/',
            description=u'正式发布单个渠道'
        )
        self.update_gray_rule = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/update_gray_rule/',
            description=u'更新单个灰度策略'
        )
        self.update_node = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/update_node/',
            description=u'更新区服节点'
        )
        self.update_platform = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/update_platform/',
            description=u'更新大区'
        )
        self.update_product = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/update_product/',
            description=u'更新单个渠道'
        )
        self.update_version = ComponentAPI(
            client=self.client, method='POST', path='/component/compapi/gcloud/update_version/',
            description=u'更新单个版本'
        )
