# -*- coding: utf-8 -*-
"""
Tencent is pleased to support the open source community by making 蓝鲸智云PaaS平台社区版 (BlueKing PaaS Community
Edition) available.
Copyright (C) 2017-2020 THL A29 Limited, a Tencent company. All rights reserved.
Licensed under the MIT License (the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://opensource.org/licenses/MIT
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.
"""

from django.conf import settings
from django.contrib import auth
from django.utils.deprecation import MiddlewareMixin

from blueapps.account.components.qcloud_ptlogin.forms import (
    AuthenticationForm, LoginForm)
from blueapps.account.conf import ConfFixture
from blueapps.account.handlers.response import ResponseHandler
from blueapps.utils import client


class LoginRequiredMiddleware(MiddlewareMixin):
    def process_view(self, request, view, args, kwargs):

        response = None

        # 登录豁免
        if getattr(view, 'login_exempt', False):
            return None
        for form in (AuthenticationForm(request.GET),
                     AuthenticationForm(request.COOKIES)):
            if form.is_valid():
                openid = form.cleaned_data['openid']
                openkey = form.cleaned_data['openkey']

                is_match = (openid == request.session.get(
                    'openid') and openkey == request.session.get('openkey'))
                if is_match and request.user.is_authenticated:
                    break

                user = auth.authenticate(request=request,
                                         openid=openid,
                                         openkey=openkey)
                if user:
                    auth.login(request, user)
                    request.COOKIES['openid'] = openid
                    request.COOKIES['openkey'] = openkey
                    request.session['openid'] = openid
                    request.session['openkey'] = openkey
                    response = self.process_view(request, view,
                                                 args, kwargs)
                    break
        else:
            handler = ResponseHandler(ConfFixture, settings)
            response = handler.build_401_response(request)

            form = LoginForm(request.COOKIES)
            if form.is_valid():
                uin = form.cleaned_data['uin']
                skey = form.cleaned_data['skey']

                openid, openkey = self.get_openid_openkey(
                    request, uin, skey)

                if openid and openkey:
                    request.COOKIES['openid'] = openid
                    request.COOKIES['openkey'] = openkey
                    request.session['openid'] = openid
                    request.session['openkey'] = openkey
                    response = self.process_view(request,
                                                 view,
                                                 args,
                                                 kwargs)
        return response

    def process_response(self, request, response):
        openid = request.COOKIES.get('openid')
        openkey = request.COOKIES.get('openkey')

        if openid and openkey:
            response.set_cookie('openid', openid)
            response.set_cookie('openkey', openkey)

        return response

    @staticmethod
    def get_openid_openkey(request, uin, skey):
        kwargs = {
            'uin': uin,
            'skey': skey,
        }
        result = client.oidb.get_openid_openkey(kwargs)
        if result['result']:
            return result['data']['openid'], result['data']['openkey']
        else:
            return (None, None)
